<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

$hari0 = date('Y-m-d', strtotime($tgl. ' - 0 days'));
$hari1 = date('Y-m-d', strtotime($tgl. ' - 1 days'));
$hari2 = date('Y-m-d', strtotime($tgl. ' - 2 days'));
$hari3 = date('Y-m-d', strtotime($tgl. ' - 3 days'));
$hari4 = date('Y-m-d', strtotime($tgl. ' - 4 days'));
$hari5 = date('Y-m-d', strtotime($tgl. ' - 5 days'));


$exhari0 = date('Y-m-d', strtotime($tgl. ' + 30 days'));
$exhari1 = date('Y-m-d', strtotime($tgl. ' + 31 days'));
$exhari2 = date('Y-m-d', strtotime($tgl. ' + 32 days'));
$exhari3 = date('Y-m-d', strtotime($tgl. ' + 33 days'));
$exhari4 = date('Y-m-d', strtotime($tgl. ' + 34 days'));
$exhari5 = date('Y-m-d', strtotime($tgl. ' + 35 days'));

if(isset($_POST['enter1'])) {
	$namaserver = $_POST['namaserver'];
	$uservpn = $_POST['uservpn'];
	$host = $_POST['host'];
	$expiredate = $_POST['expiredate'];
	$harga = $_POST['harga'];
	$saldo = $_POST['saldo'];
	$total = $saldo-$harga;
	$kurang = $saldo<$harga;
	$pengguna = $_POST['pengguna'];
	$newexpiredate = $_POST['newexpiredate'];
	$tglbaru = date('Y-m-d', strtotime($newexpiredate));

	$qdariserver = "SELECT * FROM server WHERE host = :host";
    $dariserver = $databaseConnection->prepare($qdariserver);
    $dariserver->bindParam(':host', $host);
    $dariserver->execute();
    
    while($tampilserver = $dariserver->fetch(PDO::FETCH_OBJ)){
		
		if ($kurang) {
			$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Member Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah Saldo</a> Anda.</p>
				</div>
			';
			}
			
			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 5 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '35 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance1 = :balance1 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance1', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 4 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '34 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance1 = :balance1 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance1', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 3 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '33 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance1 = :balance1 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance1', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 2 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '32 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance1 = :balance1 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance1', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 1 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '31 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance1 = :balance1 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance1', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			else {

				$connection2 = ssh2_connect($tampilserver->host, 22);
				if (ssh2_auth_password($connection2, 'root', $tampilserver->password)) {
				$result2 = ssh2_exec($connection2, "usermod -e `date -d '30 Days' +'%Y-%m-%d'` $uservpn;");
						
				//update expire
				$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
				$ubahpass = $databaseConnection->prepare($qubahpass);
				$ubahpass->bindParam(':expiredate', $newexpiredate);
				$ubahpass->bindParam(':id', $_REQUEST['id']);
				$ubahpass->execute();
				
				//update saldo
				$qubahpass1 = "UPDATE member SET balance1 = :balance1 WHERE email = :email";
				$ubahpass1 = $databaseConnection->prepare($qubahpass1);
				$ubahpass1->bindParam(':balance1', $total);
				$ubahpass1->bindParam(':email', $pengguna);
				$ubahpass1->execute();
						
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
					
				}
				else {
					$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
					';
					}
				}

		}
	}

if(isset($_POST['enter2'])) {
	$namaserver = $_POST['namaserver'];
	$uservpn = $_POST['uservpn'];
	$host = $_POST['host'];
	$expiredate = $_POST['expiredate'];
	$harga = $_POST['harga'];
	$saldo = $_POST['saldo'];
	$total = $saldo-$harga;
	$kurang = $saldo<$harga;
	$pengguna = $_POST['pengguna'];
	$newexpiredate = $_POST['newexpiredate'];
	$tglbaru = date('Y-m-d', strtotime($newexpiredate));

	$qdariserver = "SELECT * FROM server WHERE host = :host";
    $dariserver = $databaseConnection->prepare($qdariserver);
    $dariserver->bindParam(':host', $host);
    $dariserver->execute();
    
    while($tampilserver = $dariserver->fetch(PDO::FETCH_OBJ)){
		
		if ($kurang) {
			$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Reseller Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah Saldo</a> Anda.</p>
				</div>
			';
			}
			
			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 5 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '35 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance2', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 4 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '34 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance2', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 3 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '33 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance2', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 2 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '32 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance2', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			elseif ($expiredate == date('Y-m-d', strtotime($tgl. ' + 1 days'))) {
		
			$connection = ssh2_connect($tampilserver->host, 22);
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "usermod -e `date -d '31 days' +'%Y-%m-%d'` $uservpn;");
					
			//update expire
			$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':expiredate', $newexpiredate);
			$ubahpass->bindParam(':id', $_REQUEST['id']);
			$ubahpass->execute();
			
			//update saldo
			$qubahpass1 = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
			$ubahpass1 = $databaseConnection->prepare($qubahpass1);
			$ubahpass1->bindParam(':balance2', $total);
			$ubahpass1->bindParam(':email', $pengguna);
			$ubahpass1->execute();
					
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
				
			} else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
			}
			
			//End Hari H
			}

			else {

				$connection2 = ssh2_connect($tampilserver->host, 22);
				if (ssh2_auth_password($connection2, 'root', $tampilserver->password)) {
				$result2 = ssh2_exec($connection2, "usermod -e `date -d '30 Days' +'%Y-%m-%d'` $uservpn;");
						
				//update expire
				$qubahpass = "UPDATE akun SET expiredate = :expiredate WHERE id = :id";
				$ubahpass = $databaseConnection->prepare($qubahpass);
				$ubahpass->bindParam(':expiredate', $newexpiredate);
				$ubahpass->bindParam(':id', $_REQUEST['id']);
				$ubahpass->execute();
				
				//update saldo
				$qubahpass1 = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahpass1 = $databaseConnection->prepare($qubahpass1);
				$ubahpass1->bindParam(':balance2', $total);
				$ubahpass1->bindParam(':email', $pengguna);
				$ubahpass1->execute();
						
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Berhasil Perpanjang Masa Aktif!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Masa Aktif Baru: '.$newexpiredate.'</p>
					<hr>
					</div>
				';
					
				}
				else {
					$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
					';
					}
				}

		}
	}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Renew Akun</title>
</head>

<body>



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        
        <div class="warper container-fluid">
		
			<div class="page-header"><center><h3><i class="fa fa-fw fa-calendar-plus-o"></i> Renew Akun</h3></center></div>
			<?php
			$qdata0 = "SELECT * FROM akun WHERE id = :id LIMIT 0,1";
			$tdata0 = $databaseConnection->prepare($qdata0);
			$tdata0->bindParam(':id', $_REQUEST['id']);
			$tdata0->execute();
			$cdata0 = $tdata0->fetchAll();
			foreach ($cdata0 as $cdat0) {
				$expiredate = $cdat0['expiredate'];
				$dari = $cdat0['dari'];
			?>
			<div class="row">
				<div class="col-md-6" style="padding-left:0;padding-right:0">
					<div class="col-md-6">
						<div class="panel panel-default">
							<div class="panel-heading"><center>Saldo Member</center></div>
							<div class="panel-body">
								<div class="form-group">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-money fa-fw"></i></span>
										<input type="text" class="form-control" value="<?php echo number_format($deposit['balance1'], 0 , '' , '.' ); ?>" disabled />
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="panel panel-default">
							<div class="panel-heading"><center>Saldo Reseller</center></div>
							<div class="panel-body">
								<div class="form-group">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-cart-plus fa-fw"></i></span>
										<input type="text" class="form-control" value="<?php echo number_format($deposit['balance2'], 0 , '' , '.' ); ?>" disabled />
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="panel panel-default">
							<div class="panel-heading"><center>Catatan</center></div>
							<div class="panel-body">
								<div class="form-group">
									<center>Dengan melakukan Renew Akun berarti Anda menyetujui Peraturan Server Kami.<br>
									Harga yang digunakan mengikuti Harga saat pembelian/pembuatan Akun.<br>
									Renew akun dapat dilakukan pada H-5 / H-4 / H-3 / H-2 / H-1 / H-0.<hr></center>
								</div>
							</div>
						</div>
					</div>
				</div>
            	<div class="col-md-6">
					<?php if(isset($saldokurang)){ echo $saldokurang; } ?>
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading">Renew Akun </div>
                        <div class="panel-body">
								<?php if($cdat0['dari'] == "Member") { ?>
								<form  method="post" action="">
									<!-- Database Account -->
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-database fa-fw"></i></span>
											<input type="text" class="form-control" name="namaserver" value="<?php echo $cdat0['namaserver']; ?>" readonly />
										</div>
									</div>
									<input type="hidden" class="form-control" name="host" value="<?php echo $cdat0['host']; ?>" />
									<!-- Database Server -->
									<?php
										$qdata1 = "SELECT * FROM server WHERE host = :host LIMIT 0,1";
										$tdata1 = $databaseConnection->prepare($qdata1);
										$tdata1->bindParam(':host', $cdat0['host']);
										$tdata1->execute();
										$cdata1 = $tdata1->fetchAll();
										foreach ($cdata1 as $cdat1) {
											$harga1 = $cdat1['harga1'];
										}
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-money fa-fw"></i></span>
											<input type="text" class="form-control" value="Saldo Member - <?php echo number_format($cdat1['harga1'], 0 , '' , '.' ); ?>" disabled />
											<input type="hidden" class="form-control" name="harga" value="<?php echo $cdat1['harga1']; ?>" readonly />
										</div>
									</div>
									
									<!-- Database Member -->
									<?php
									$qdata2 = "SELECT * FROM member WHERE email = :pengguna LIMIT 0,1";
									$tdata2 = $databaseConnection->prepare($qdata2);
									$tdata2->bindParam(':pengguna', $menuusername);
									$tdata2->execute();
									$cdata2 = $tdata2->fetchAll();
									foreach ($cdata2 as $cdat2) {
										$balance1 = $cdat2['balance1'];
									}
									?>
									<input type="hidden" class="form-control" name="saldo" value="<?php echo $balance1; ?>" readonly />
									<input type="hidden" class="form-control" name="pengguna" value="<?php echo $menuusername; ?>" readonly />
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-user fa-fw"></i></span>
											<input type="text" class="form-control" name="uservpn" value="<?php echo $cdat0['uservpn'];?>" readonly />
										</div>
									</div>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar-o fa-fw"></i></span>
											<input type="text" class="form-control" name="expiredate" value="<?php echo $cdat0['expiredate'];?>" readonly />
										</div>
									</div>
									<!-- Perpanjang H-5 -->
									<?php
										if ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 5 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari5;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-5).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter1" name="enter1" value="enter1">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H-4 -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 4 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari4;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-4).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter1" name="enter1" value="enter1">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H-3 -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 3 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari3;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-3).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter1" name="enter1" value="enter1">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H-2 -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 2 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari2;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-2).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter1" name="enter1" value="enter1">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H-1 -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 1 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari1;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-1).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter1" name="enter1" value="enter1">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 0 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari0;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter1" name="enter1" value="enter1">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Expired -->
									<?php
										}  elseif ($cdat0['expiredate'] < $tgl) {
									?>
									<div class="alert alert-danger" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
										<p>Akun Expired</p>
									</div>
									<hr class="dotted">
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter1" name="enter1" value="enter1" disabled >
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Tidak Bisa Renew -->
									<?php 
									} else {
									?>
									<div class="alert alert-danger" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
										<p>Saat ini Anda tidak bisa Renew akun</p>
										<p>Renew akun dapat dilakukan pada H-5.</p>
									</div>
									<hr class="dotted">
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter1" name="enter1" value="enter1" disabled >
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<?php } ?>
								</form>
								<?php } 
								elseif($cdat0['dari'] == "Reseller") { ?>
								<form  method="post" action="">
									<!-- Database Account -->
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-database fa-fw"></i></span>
											<input type="text" class="form-control" name="namaserver" value="<?php echo $cdat0['namaserver']; ?>" readonly />
										</div>
									</div>
									<input type="hidden" class="form-control" name="host" value="<?php echo $cdat0['host']; ?>" />
									<!-- Database Server -->
									<?php
										$qdata1 = "SELECT * FROM server WHERE host = :host LIMIT 0,1";
										$tdata1 = $databaseConnection->prepare($qdata1);
										$tdata1->bindParam(':host', $cdat0['host']);
										$tdata1->execute();
										$cdata1 = $tdata1->fetchAll();
										foreach ($cdata1 as $cdat1) {
											$harga2 = $cdat1['harga2'];
										}
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-money fa-fw"></i></span>
											<input type="text" class="form-control" value="Saldo Reseller - <?php echo number_format($cdat1['harga2'], 0 , '' , '.' ); ?>" disabled />
											
											<input type="hidden" class="form-control" name="harga" value="<?php echo $cdat1['harga2']; ?>" readonly />
										</div>
									</div>
									
									<!-- Database Member -->
									<?php
									$qdata2 = "SELECT * FROM member WHERE email = :pengguna LIMIT 0,1";
									$tdata2 = $databaseConnection->prepare($qdata2);
									$tdata2->bindParam(':pengguna', $menuusername);
									$tdata2->execute();
									$cdata2 = $tdata2->fetchAll();
									foreach ($cdata2 as $cdat2) {
										$balance2 = $cdat2['balance2'];
									}
									?>
									<input type="hidden" class="form-control" name="saldo" value="<?php echo $balance2; ?>" readonly />
									<input type="hidden" class="form-control" name="pengguna" value="<?php echo $menuusername; ?>" readonly />
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-user fa-fw"></i></span>
											<input type="text" class="form-control" name="uservpn" value="<?php echo $cdat0['uservpn'];?>" readonly />
										</div>
									</div>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar-o fa-fw"></i></span>
											<input type="text" class="form-control" name="expiredate" value="<?php echo $cdat0['expiredate'];?>" readonly />
										</div>
									</div>
									<!-- Perpanjang H-5 -->
									<?php
										if ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 5 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari5;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-5).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter2" name="enter2" value="enter2">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H-4 -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 4 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari4;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-4).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter2" name="enter2" value="enter2">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H-3 -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 3 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari3;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-3).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter2" name="enter2" value="enter2">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H-2 -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 2 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari2;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-2).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter2" name="enter2" value="enter2">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H-1 -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 1 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari1;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H-1).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter2" name="enter2" value="enter2">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Perpanjang H -->
									<?php
										} elseif ($cdat0['expiredate'] == date('Y-m-d', strtotime($tgl. ' + 0 days'))) {
									?>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
											<input type="text" class="form-control" name="newexpiredate" value="<?php echo $exhari0;?>" readonly />
										</div>
										<small>Masa Aktif Baru (H).</small>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter2" name="enter2" value="enter2">
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Expired -->
									<?php
										}  elseif ($cdat0['expiredate'] < $tgl) {
									?>
									<div class="alert alert-danger" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
										<p>Akun Expired</p>
									</div>
									<hr class="dotted">
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter2" name="enter2" value="enter2" disabled >
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<!-- Tidak Bisa Renew -->
									<?php 
									} else {
									?>
									<div class="alert alert-danger" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
										<p>Saat ini Anda tidak bisa Renew akun</p>
										<p>Renew akun dapat dilakukan pada H-5.</p>
									</div>
									<hr class="dotted">
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="enter2" name="enter2" value="enter2" disabled >
											<i class="fa fa-calendar fa-fw"></i> Renew
										</button>
										<a href="akun.php">
											<button type="button" class="btn btn-danger"><i class="fa fa-arrow-circle-left"></i> Batal</button>
										</a>
									</div>
									<?php } ?>
								</form>
								<?php } 
								else { echo ""; } ?>
						</div>
                    </div>
                 </div>
            </div>
			<?php } ?>
       </div>
        <!-- Warper Ends Here (working area) -->
        
        <?php include 'base/footer.php'; ?>
    
    </section>
    <!-- Content Block Ends Here (right box)-->
    
    
    
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>