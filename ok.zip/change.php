<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');
$habis = date('Y-m-d', strtotime($tgl. ' + 30 days'));

if(isset($_POST['enter'])) {
	$namaserver = $_POST['namaserver'];
	$uservpn = $_POST['uservpn'];
	$passvpn = $_POST['passvpn'];
	$host = $_POST['host'];

	$qdariserver = "SELECT * FROM server WHERE host = :host";
    $dariserver = $databaseConnection->prepare($qdariserver);
    $dariserver->bindParam(':host', $host);
    $dariserver->execute();
    
    while($tampilserver = $dariserver->fetch(PDO::FETCH_OBJ)){

    $connection = ssh2_connect($tampilserver->host, 22);

	if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
	$result = ssh2_exec($connection, "{ echo $passvpn; echo $passvpn; } | passwd $uservpn;");
			
	//update
	$qubahpass = "UPDATE akun SET passvpn = :passvpn WHERE id = :id";
	$ubahpass = $databaseConnection->prepare($qubahpass);
	$ubahpass->bindParam(':passvpn', $passvpn);
	$ubahpass->bindParam(':id', $_REQUEST['id']);
	$ubahpass->execute();
			
	$berhasil = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Berhasil Merubah Password!</h4>
			<p>IP Address : '.$host.'</p>
			<p>Username : '.$uservpn.'</p>
			<p>Password Baru : '.$passvpn.'</p>
			<hr>
			<p class="mb-0">Harap Simpan Password Baru Anda.</p>
			</div>
		';
		
	} 
	
	else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Gagal Merubah Password!</h4>
			<p>Ada Masalah Pada Server</p>
			<hr>
			<p class="mb-0">Silahkan Hubungi Admin.</p>
			</div>
		';
	}

	}
}
	
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title  -->
<title>Ganti Password</title>
</head>

<body>

    <?php include 'base/preloader.php'; ?>

	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
		
        <div class="warper container-fluid">
		
			<div class="page-header"><center><h3><i class="fa fa-fw fa-key"></i> Ganti Password Akun</h3></center></div>
           
            <div class="row">
            
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
					<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-fw fa-terminal"></i> Akun SSH</div>
                        <div class="panel-body">
							 <?php
                            $qdata = "SELECT * FROM akun WHERE id = :id LIMIT 0,1";
                            $tdata = $databaseConnection->prepare($qdata);
                            $tdata->bindParam(':id', $_REQUEST['id']);
                            $tdata->execute();
                            $cdata = $tdata->fetchAll();
                            foreach ($cdata as $cdat) {
                            ?>
                        	<form  method="post" class="validator-form" action="">
                            <div class="form-group">
                                <label class="control-label">Nama Server</label>
                                <input type="text" class="form-control" name="namaserver" value="<?php echo $cdat['namaserver']; ?>" readonly />
                            </div>
                            <div class="form-group">
                                <input type="hidden" class="form-control" name="host" value="<?php echo $cdat['host']; ?>" />
                            </div>
                            <div class="form-group">
                                <label class="control-label">Nama User</label>
                                <input type="text" class="form-control" name="uservpn" value="<?php echo $cdat['uservpn'];?>" readonly />
                            </div>
                            <div class="form-group">
                                <label class="control-label">Password Baru</label>
                                <input type="text" class="form-control" name="passvpn" required />
                            </div>
                            <hr class="dotted">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary" id="enter" name="enter" value="enter">
									<i class="fa fa-save fa-fw"></i> Ganti
								</button>
                                <a href="akun.php">
									<button type="button" class="btn btn-info" id="resetBtn">
										<i class="fa fa-arrow-circle-left fa-fw"></i> Kembali
									</button>
								</a>
                            </div>
                            </form>
                                 <?php } ?>         
                        </div>
                    </div>
                 </div>
            </div>
       </div>

	   <!-- Footer -->
        <?php include 'base/footer.php'; ?>
		
    </section>
     
    
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>