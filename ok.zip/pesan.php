<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

if(isset($_POST['enter'])) {
	$nama_pengirim = $_POST['nama_pengirim'];
	$sadmin = $_POST['sadmin'];
	$sname = $_POST['sname'];
	$email = $_POST['email'];
	$pesan = $_POST['pesan'];
	 
	 
	// SMTP Mailer
	require_once('function.php');
	$to       = $sadmin;
	$subject  = "Informasi Pesan Masuk";
	// Message SMTP Mailer
	$message  = "
	<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;margin-to:15px;border-top:1px solid #eee;font-size:16px'><b>Pesan Masuk | ".$sname."</b></div>
	<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
		<tbody>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px;width:100px'>Email</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$email."</th>
			<tr>
			<tr>
				<td style='padding:8px 10px'>Nama Pengirim</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$nama_pengirim."</th>
			</tr>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px;width:100px'>Isi Pesan</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$pesan."</th>
			<tr>
			<tr>
				<td style='padding:8px 10px'>Tanggal Masuk</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$tgl."</th>
			</tr>
		</tbody>
	</table>
	";
	$from_name = 'no reply';
	$from = $email;
	smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
	
	$qqcek = "SELECT * FROM saran WHERE email = :email";
	$qcek = $databaseConnection->prepare($qqcek);
	$qcek->bindParam(':email', $email);
	$qcek->execute();
	
if($qcek->rowCount() > 0){
	$qupdate = "UPDATE saran SET pesan = :pesan WHERE email = :email";
	$update = $databaseConnection->prepare($qupdate);
	$update->bindParam(':pesan', $pesan);
	$update->bindParam(':email', $email);
	$update->execute();
	
	$terkirim = '
		<div class="alert alert-success" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<p>Pesan Terkirim!</p>
		</div>
	';
}
else {
	$qsimpan = "INSERT INTO saran SET nama_pengirim = :nama_pengirim, email = :email, pesan = :pesan";
	$hsimpan = $databaseConnection->prepare($qsimpan);
	$hsimpan->bindParam(':nama_pengirim', $nama_pengirim);
	$hsimpan->bindParam(':email', $email);
	$hsimpan->bindParam(':pesan', $pesan);
	$hsimpan->execute();

	$terkirim = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Pesan Terkirim!</p>
			</div>
		';
	}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Pesan</title>

<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>

<body>	



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
	
		<?php include 'base/header.php'; ?>
		
        <div class="warper container-fluid">
			<div class="page-header"><center><h3><i class="fa fa-fw fa-envelope-o"></i> Pesan</h3></center></div>
			<div class="row">
				<div class="col-md-6">
					<div class="panel panel-default" style="min-height:18pc">
						<div class="panel-heading"><center>Pesan Masuk</center></div>
						<div class="panel-body">
							<textarea style="resize: none;width:100%;min-height:268px;border:none;background:transparent;" disabled ><?php
								if($deposit['pesan'] == '') {
								 echo 'Tidak Ada Pesan Masuk';
								} else {
								echo $deposit['pesan'];
								}
								?></textarea>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<?php if(isset($terkirim)){ echo $terkirim; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default" style="min-height:18pc">
                        <div class="panel-heading"><center>Kirim Pesan Ke Admin</center></div>
						<div class="panel-body" style="min-height:18pc">
							<form  method="post" class="validator-form" action="" enctype="multipart/form-data">
								<?php
									$qtsite = "SELECT * FROM site";
									$tsite = $databaseConnection->prepare($qtsite);
									$tsite->execute();
									$site = $tsite->fetchAll();
									foreach ($site as $site)
									$sadmin = $site['email'];
									$sname = $site['name'];
									?>
									<input type="hidden" class="form-control" name="sadmin" value="<?php echo $sadmin; ?>" readonly />
									<input type="hidden" class="form-control" name="sname" value="<?php echo $sname; ?>" readonly />
									<input type="hidden" class="form-control" name="nama_pengirim"  value="<?php echo $namaku;?>" readonly />
									<input type="hidden" class="form-control" name="email" value="<?php echo $menuusername;?>" readonly />
								<div class="form-group">
									<label class="control-label">Pesan</label>
									<textarea type="text" class="form-control" name="pesan"  maxlength="200" style="height:6.5pc" required ></textarea>
									<script id="jsbin-javascript">
									$("textarea").on("keypress",function(e){
									var val = $(this).val();
									var open = val.indexOf('<');
									var close = val.indexOf('>');
									if(open!==-1 && close!==-1) {
									$(this).val(val.replace(val.slice(open,close+1),""));
									}
									});
									</script>
								</div>
								<hr>
								<div class="form-group">
									<button type="submit" class="btn btn-primary" id="enter" name="enter" value="enter">
										<i class="fa fa-send fa-fw"></i> Kirim
									</button>
									<button type="reset" class="btn btn-danger" id="resetBtn">
										<i class="fa fa-trash fa-fw"></i> Reset
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php include 'base/footer.php'; ?>

    </section>
    
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
   
</body>

</html>