<?php
ob_start();
session_start();
if(isset($_SESSION['email'])) {
	header("location: beranda.php");
} else {
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

function yourip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'IP Tidak Dikenali';
 
    return $ipaddress;
}


if(isset($_POST['submit'])) {
$email = $_POST['email'];
$password = $_POST['password'];

$qlogin = "SELECT * FROM member WHERE email = :email";
$login = $databaseConnection->prepare($qlogin);
$login->bindParam(':email', $email);
$login->execute();
$row = $login->fetchObject();
	
	if($row) {
		if($row->status == "Kunci") {
			$qlog = "INSERT INTO memberlog SET email = :email, waktulogin = :waktulogin, valid = :valid, ip = :ip";
			$waktulogin = date('Y-m-d H:i:s');
			$valid = "Akun Terkunci";
			$ip = yourip();
			$log = $databaseConnection->prepare($qlog);
			$log->bindParam(':email', $email);
			$log->bindParam(':valid', $valid);
			$log->bindParam(':waktulogin', $waktulogin);
			$log->bindParam(':ip', $ip);
			$log->execute();
			$pesan = '<div class="alert alert-danger" role="alert">
			<p><b>Akun Anda Di Kunci</b><br>Silahkan Hubungi Admin untuk Lebih Lanjut</p>
			</div>';
		}
		elseif($row->status == "Pending") {
			$qlog = "INSERT INTO memberlog SET email = :email, waktulogin = :waktulogin, valid = :valid, ip = :ip";
			$waktulogin = date('Y-m-d H:i:s');
			$valid = "Akun Pending";
			$ip = yourip();
			$log = $databaseConnection->prepare($qlog);
			$log->bindParam(':email', $email);
			$log->bindParam(':valid', $valid);
			$log->bindParam(':waktulogin', $waktulogin);
			$log->bindParam(':ip', $ip);
			$log->execute();
			$pesan = '<div class="alert alert-warning" role="alert">
			<p><b>Akun Belum Aktif</b><br>Silahkan cek email Anda untuk aktifasi</p>
			</div>';
		}
		elseif(password_verify($password, $row->password)) {
			$_SESSION['email'] = $row->email;
			//alihkan ke halaman index
			$qlog = "INSERT INTO memberlog SET email = :email, waktulogin = :waktulogin, valid = :valid, ip = :ip";
			$waktulogin = date('Y-m-d H:i:s');
			$valid = "Sukses";
			$ip = yourip();
			$log = $databaseConnection->prepare($qlog);
			$log->bindParam(':email', $email);
			$log->bindParam(':valid', $valid);
			$log->bindParam(':waktulogin', $waktulogin);
			$log->bindParam(':ip', $ip);
			$log->execute();
			header('location: index.php');
		}
		else {
			$qlog = "INSERT INTO memberlog SET email = :email, waktulogin = :waktulogin, valid = :valid, ip = :ip";
			$waktulogin = date('Y-m-d H:i:s');
			$valid = "Salah Password";
			$ip = yourip();
			$log = $databaseConnection->prepare($qlog);
			$log->bindParam(':email', $email);
			$log->bindParam(':valid', $valid);
			$log->bindParam(':waktulogin', $waktulogin);
			$log->bindParam(':ip', $ip);
			$log->execute();
			
			$pesan = '<div class="alert alert-danger" role="alert">
			<p><center><b>Password salah</b></center></p>
			</div>';
		}
	}
	else {
		$qlog = "INSERT INTO memberlog SET email = :email, waktulogin = :waktulogin, valid = :valid, ip = :ip";
		$waktulogin = date('Y-m-d H:i:s');
		$valid = "Tidak Terdaftar";
		$ip = yourip();
		$log = $databaseConnection->prepare($qlog);
		$log->bindParam(':email', $email);
		$log->bindParam(':valid', $valid);
		$log->bindParam(':waktulogin', $waktulogin);
		$log->bindParam(':ip', $ip);
		$log->execute();
		$pesan = '<div class="alert alert-danger" role="alert">
			<p><center><b>Email tidak terdaftar</b></center></p>
			</div>';
	}
}
?>

<!DOCTYPE html>
<html>
<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<title>Login Page</title>

<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>

<body style="background-color:#121215">
	<center>
        <div class="warper container-fluid" style="padding: 0;margin:0;min-height:300px;max-width:400px;">
			<div class="row" style="margin:auto">
            	<div class="col-md-12">
				<div class="page-header" style="margin:25px 0 5px"><center><h1 style="margin-bottom:0">Login Page</h1></center></div>
                	<div class="panel panel-default" style="margin-bottom:0">
                        <div class="panel-heading"><center>Login Page</center></div>
                        <div class="panel-body">
							<form  method="post" action="">
								<div class="form-group">
									<label class="control-label">Email</label>
									<input class="form-control" type="email" name="email" maxlength="70" placeholder="Email" required>
								</div>
								<div class="form-group">
									<label class="control-label">Password</label>
									<input class="form-control" type="password" name="password" maxlength="70" placeholder="Password" required>
								</div>
								<?php if(isset($pesan)){ echo '<font color=#d4a601;>'.$pesan.'</font> <hr>'; } ?>
								<div class="form-group">
									<div class="col-md-6" style="padding: 2px">
										<button type="submit" class="btn btn-primary" style="width:100%" name="submit"><b>Login</b></button>
									</div>
									<div class="col-md-6" style="padding: 2px">
										<a href="daftar.php">
											<button type="button" class="btn btn-success" style="width:100%" id="resetBtn"><b>Daftar</b></button>
										</a>
									</div>
								</div>
							</form>
						</div>
						<hr>
						<a href="lostpassword.php"><b>Lupa Password?</b></a>
						<br>
						<br>
					</div>
				</div>
				<div class="col-md-12" style="padding: 2px 2px">
					<?php
					$qtsite = "SELECT * FROM site";
					$tsite = $databaseConnection->prepare($qtsite);
					$tsite->execute();
					$site = $tsite->fetchAll();
					foreach ($site as $site)
					$fb = $site['fb'];
					$wa = $site['wa'];
					$url = $site['url'];
					$name = $site['name'];
					?>
					<div class="col-md-12" style="padding-top: 6px">
						<div class="form-group">
						<a href="#">
							<button type="submit" class="btn btn-warning" style="width:100%" data-toggle="modal" data-target="#harga">
							<i class="fa fa-fw fa-search"></i> Chek Harga
							</button>
						</a>
					</div>
					</div>
					<div class="col-md-12" style="padding-top: 6px">
						<label class="control-label">Kontak Admin</label>
					</div>
					<div class="col-md-6">
					<div class="form-group">
						<a target="_blank" href="
							<?php if($fb== '') { ?>
							<?php echo "#" ?>
							<?php } else { ?> <?php echo $site['fb']; }?>
							">
							<button type="submit" class="btn btn-info" style="width:100%">
							<b><i class="fa fa-fw fa-facebook-square"></i> Facebook</b>
							</button>
						</a>
					</div>
					</div>
					<div class="col-md-6">
					<div class="form-group">
						<a target="_blank" href="
							<?php if($wa== '') { ?>
							<?php echo "#" ?>
							<?php } else { ?> http://api.whatsapp.com/send?phone=<?php echo $site['wa']; }?>
							">
							<button type="button" class="btn btn-success" style="width:100%">
							<b><i class="fa fa-fw fa-whatsapp"></i> Whatsapp</b>
							</button>
						</a>
					</div>
					</div>
				</div>
			</div>
		</div>
	</center>

	<div class="modal fade" id="harga" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h3 class="modal-title" id="exampleModalLabel"><center>List Harga<center></h3>
				</div>
				<div class="modal-body">
					<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
						<thead>
							<tr>
								<th><small>Server</small></th>
								<th><small>Member</small></th>
								<th><small>Reseller</small></th>
							</tr>
						</thead>
						<tbody>
							<?php
							$qtserver = "SELECT * FROM server";
							$tserver = $databaseConnection->prepare($qtserver);
							$tserver->execute();
							$server = $tserver->fetchAll();
							foreach ($server as $serv) {
							?>
							<tr class="odd gradeX">
								<td><small><?php echo $serv['namaserver'];?></small></td>
								<td><small><?php echo number_format($serv['harga1'], 0 , '' , '.' ); ?></small></td>
								<td><small><?php echo number_format($serv['harga2'], 0 , '' , '.' ); ?></small></td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	
	
	<p class="text-center" style="padding-top: 20px">
		Copyright 2021 
		<a target="_blank" href="
			<?php if($url== '') { ?>
			<?php echo "#" ?>
			<?php } else { ?> <?php echo $site['url']; }?>
			">
			<b>
			<?php if($name== '') { ?>
			<?php echo "#" ?>
			<?php } else { ?> <?php echo $site['name']; } }?>
			</b>
		</a>
	</p>
	
	<script id="jsbin-javascript">
		$("input").on("keypress",function(e){
		var val = $(this).val();
		var open = val.indexOf('<');
		var close = val.indexOf('>');
		if(open!==-1 && close!==-1) {
		$(this).val(val.replace(val.slice(open,close+1),""));
		}
		});
	</script>
	
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>

</body>
</html>