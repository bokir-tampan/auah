<?php
ob_start();
session_start();
include 'asset/css/config.php';

if(isset($_POST['ganti'])) {
	
	$passwordtext = $_POST['password'];
	$password = password_hash($_POST['password'], PASSWORD_DEFAULT, ['cost' => 12,]);
	
	$qubahpass = "UPDATE member SET password = :password WHERE email = :email";
	$ubahpass = $databaseConnection->prepare($qubahpass);
	$ubahpass->bindParam(':password', $password);
	$ubahpass->bindParam(':email', $_SESSION['email']);

	if($ubahpass->execute()) {
		$message = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Password Berhasil Dirubah!</h4>
			<p>Password Baru : '.$passwordtext.'.</p>
			<p>Silahkan catat/ingat password yang tersebut.</p>
			<hr>
			<p class="mb-0">Jika Anda Lupa password, Silahkan Hubungi <a href="kontak.php">Admin</a>.</p>
			</div>
		';
	} else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Gagal Merubah Password!</h4>
			<p>Ada Masalah Pada Database.</p>
			<hr>
			<p class="mb-0">Silahkan Hubungi <a href="kontak.php">Admin</a>.</p>
			</div>
		';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Ganti Password</title>
</head>

<body>



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>

        <div class="warper container-fluid">
            <div class="page-header"><center><h3><i class="fa fa-fw fa-key"></i> Ganti Password</h3></center></div>
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
				<?php if(isset($message)){ echo $message; } ?>
				<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-fw fa-user"></i> Ganti Password</div>
                        <div class="panel-body">
							<?php
							$qtganti = "SELECT * FROM member WHERE email = :email";
							$tganti = $databaseConnection->prepare($qtganti);
							$tganti->bindParam(':email', $menuusername);
							$tganti->execute();
							$ganti = $tganti->fetchAll();
							foreach ($ganti as $gantii) {
							?>
                        	<form  method="post" class="validator-form" action="">
								<div class="col-lg-6">
									<div class="form-group">
										<small>Password Baru</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-key fa-fw"></i></span>
											<input type="password" class="form-control" name="password"/>
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<small>Ulangi Password</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-key fa-fw"></i></span>
											<input type="password" class="form-control" name="confirmPassword" placeholder="******"/>
										</div>
									</div>
								</div>
								<div class="col-lg-12">
									<hr class="dotted">
									<div class="form-group">
										<button type="submit" class="btn btn-primary" name="ganti" value="change">
											<i class="fa fa-save fa-fw"></i> Ganti
										</button>
										<a href="beranda.php">
											<button type="button" class="btn btn-info" id="resetBtn"><i class="fa fa-arrow-circle-left fa-fw"></i> Kembali</button>
										</a>
									</div>
								</div>
                            </form>
							<?php } ?>            
                        </div>
                    </div>
                 </div>
			</div>
       </div>
	   
	   <?php include 'base/footer.php'; ?>
    
    </section>    
    
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>