<?php

phpinfo()

?>