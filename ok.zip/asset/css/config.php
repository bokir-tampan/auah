<?php
define('_HOSTNAME_', 'localhost');
define('_USERNAME_', 'imade_demopanel');
define('_DBPASSWORD', 'F~~g3M]yhfYp');
define('_DATABASENAME_', 'imade_demopanel');
 
 try {
 $databaseConnection = new PDO('mysql:host='._HOSTNAME_.';dbname='._DATABASENAME_, _USERNAME_, _DBPASSWORD);
 $databaseConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 } catch(PDOException $e) {
 echo 'ERROR: ' . $e->getMessage();
 }
?>