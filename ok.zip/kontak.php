<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling -->
<link rel="stylesheet" href="asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts -->


<!-- Base Styling -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Kontak Page</title>
</head>

<body>	



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
		
        <div class="warper container-fluid">
			
			<div class="page-header"><center><h3><i class="fa fa-fw fa-phone-square"></i> Kontak</h3></center></div>
			
			<!-- Upload Bukti Transfer -->
			<div class="row">
				<div class="col-md-6">
                	<div class="panel panel-default" style="height:15pc">
                        <div class="panel-heading"><center><i class="fa fa-fw fa-phone"></i> Kontak Admin</center></div>
						<div class="panel-body" style="padding:0">
							<?php
								$qtsite = "SELECT * FROM site";
								$tsite = $databaseConnection->prepare($qtsite);
								$tsite->execute();
								$site = $tsite->fetchAll();
								foreach ($site as $site) 
							?>
							<table class="table">
								<tbody>
									<tr>
										<td>Facebook</td>
										<td><?php echo $site['fb']; ?></td>
									</tr>
									<tr>
										<td>Whatsapp</td>
										<td><?php echo $site['wa']; ?></td>
									</tr>
									<tr>
										<td>PIN BBM</td>
										<td><?php echo $site['bbm']; ?></td>
									</tr>
									<tr>
										<td>ID LIne</td>
										<td><?php echo $site['line']; ?></td>
									</tr>
									<tr>
										<td>Twitter</td>
										<td><?php echo $site['twitter']; ?></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>

				<div class="col-md-6">
                	<div class="panel panel-default" style="min-height:15pc">
                        <div class="panel-heading"><center><i class="fa fa-fw fa-info"></i> About Panel</center></div>
						<div class="panel-body" style="padding:0">
							<font color=#2b2f3e>
							<center><h1>Premium SSH Panel</h1></center>
							<center><h5>ForNesia.com</h5><hr></center>
							<center><h5>Contact Person:</h5></center>
							<center><h5><i class="fa fa-envelope fa-fw"></i> fornesiafreak@gmail.com</h5><hr></center>
							</font>
						</div>
					</div>
				</div>
			</div>

		</div>

		<?php include 'base/footer.php'; ?>
		
    </section>
    
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
   
</body>

</html>