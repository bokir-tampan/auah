<?php
function passFunc2($len2, $set2 = "") {
$gen2 = "";

for($i=0;$i<$len2;$i++) {
$set2 = str_shuffle($set2);
$gen2 .= $set2[0];
}

return $gen2;
}
 $passcode2=passFunc2(6,'abcdefghijklmnopqrstuvwxyzABCDEFGHIZKLMNOPQRSTUVWXYZ123456789');
 echo $passcode2;
?>