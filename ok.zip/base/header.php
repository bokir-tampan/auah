<header class="top-head container-fluid">
   <?php
	$qtsite = "SELECT * FROM site";
	$tsite = $databaseConnection->prepare($qtsite);
	$tsite->execute();
	$site = $tsite->fetchAll();
	foreach ($site as $site) 
	?>
	<button type="button" class="navbar-toggle pull-left">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
	<nav class=" navbar-default hidden-xs" role="navigation">
		<ul class="nav navbar-nav">
			<?php
				if($site['url'] == '') {
				 echo '<li><a href="index.php"><b><i class="fa fa-globe fa-fw"></i> ' . $site['name'] . '</b></a></li>';
				} else {
				echo '<li><a href="'.$site['url'].'" target="_blank"><b><i class="fa fa-globe fa-fw"></i> ' . $site['name'] . '</b></a></li>';
				}
			?>
			<?php
				if($site['fb'] == '') {
				 echo '';
				} else {
				echo '<li><a href="' . $site['fb'] . '" target="_blank">
				<b>
				<i class="fa fa-facebook fa-fw"></i> Facebook
				</b></a></li>';
				}
			?>
			<?php
				if($site['wa'] == '') {
				 echo '';
				} else {
				echo '<li><a href="http://api.whatsapp.com/send?phone=' . $site['wa'] . '" target="_blank">
				<b>
				<i class="fa fa-whatsapp fa-fw"></i> Whatsapp
				</b></a></li>';
				}
			?>
		</ul>
	</nav>
	<ul class="nav-toolbar">
		<li class="dropdown">
		<a href="#" data-toggle="dropdown">
			<i class="fa fa-envelope-o"></i>
			<?php
				if($deposit['pesan'] == '') {
				 echo '';
				} else {
				echo '<span class="badge bg-info">1</span>';
				}
			?>
		</a>
			<div class="dropdown-menu md arrow pull-right panel panel-default arrow-top-right messages-dropdown">
				<div class="panel-heading">Pesan Masuk</div>
				<div class="list-group">
					<?php
						if($deposit['pesan'] == '') {
						echo '<a class="list-group-item">
						<div class="media">
							<div class="media-body">Tidak Ada Pesan Masuk</div>
						</div>
					</a>';
						} else {
							echo '<a class="list-group-item">
						<div class="media">
							<div class="user-status busy pull-left">
								<img class="media-object img-circle pull-left" src="images/admin.png" alt="Admin" width="40">
							</div>
							<div class="media-body">'. $deposit['pesan'] . '<br><small class="text-muted">From Admin</small></div>
						</div>
					</a>';
					}
					?>
					
							
				</div>
			</div>
		</li>
		<li class="dropdown">
			<a href="#" data-toggle="dropdown">
				<i class="fa fa-warning"></i>
				<?php
					$qtserver = "SELECT * FROM akun WHERE username = :pengguna";
					$tserver = $databaseConnection->prepare($qtserver);
					$tserver->bindParam(':pengguna', $menuusername);
					$tserver->execute();
					while ($serv = $tserver->fetch(PDO::FETCH_OBJ)) {
				?>
				<?php
					date_default_timezone_set('Asia/Jakarta');
					$habis = $serv->expiredate; 
					$tgl = date('Y-m-d');
					$tgl_habis0 = strtotime($habis . ' - 0 Days');
					$tgl_habis1 = strtotime($habis . ' - 1 Days');
					$tgl_habis2 = strtotime($habis . ' - 2 Days');
					$tgl_habis3 = strtotime($habis . ' - 3 Days');
					$tgl_habis4 = strtotime($habis . ' - 4 Days');
					$tgl_habis5 = strtotime($habis . ' - 5 Days');
					$tgl_skrg = strtotime($tgl);

					if ($tgl_habis5 == $tgl_skrg) {
						echo '<span class="badge bg-warning"> </span>';
						} elseif ($tgl_habis4 == $tgl_skrg) {
							echo '<span class="badge bg-warning"> </span>';
						} elseif ($tgl_habis3 == $tgl_skrg) {
							echo '<span class="badge bg-warning"> </span>';
						} elseif ($tgl_habis2 == $tgl_skrg) {
							echo '<span class="badge bg-warning"> </span>';
						} elseif ($tgl_habis1 == $tgl_skrg) {
							echo '<span class="badge bg-warning"> </span>';
						} elseif ($tgl_habis0 == $tgl_skrg) {
							echo '<span class="badge bg-warning"> </span>';
						} 
						else {
						echo '';
						}
				?>
				<?php } ?>
			</a>
			<div class="dropdown-menu arrow pull-right md panel panel-default arrow-top-right notifications">
				<div class="panel-heading">
					Renew Akun
				</div>
				<div class="list-group">
					<a href="akun.php" class="list-group-item">
						<div class="media">
							<div class="media-body">
								<?php
								$qtserver = "SELECT * FROM akun WHERE username = :pengguna";
								$tserver = $databaseConnection->prepare($qtserver);
								$tserver->bindParam(':pengguna', $menuusername);
								$tserver->execute();
								while ($serv = $tserver->fetch(PDO::FETCH_OBJ)) {
								?>
								<?php
								date_default_timezone_set('Asia/Jakarta');
								$habis = $serv->expiredate; 
								$tgl = date('Y-m-d');
								$tgl_habis0 = strtotime($habis . ' - 0 Days');
								$tgl_habis1 = strtotime($habis . ' - 1 Days');
								$tgl_habis2 = strtotime($habis . ' - 2 Days');
								$tgl_habis3 = strtotime($habis . ' - 3 Days');
								$tgl_habis4 = strtotime($habis . ' - 4 Days');
								$tgl_habis5 = strtotime($habis . ' - 5 Days');
								$tgl_skrg = strtotime($tgl);

								if ($tgl_habis5 == $tgl_skrg) {
								echo "<font color=#FF0000>User : " . $serv->uservpn . " (H-5 Expired)</font><br>";
									} elseif ($tgl_habis4 == $tgl_skrg) {
										echo "<font color=#FF0000>User : " . $serv->uservpn . " (H-4 Expired)</font><hr>";
									} elseif ($tgl_habis3 == $tgl_skrg) {
										echo "<font color=#FF0000>User : " . $serv->uservpn . " (H-3 Expired)</font><hr>";
									} elseif ($tgl_habis2 == $tgl_skrg) {
										echo "<font color=#FF0000>User : " . $serv->uservpn . " (H-2 Expired)</font><hr>";
									} elseif ($tgl_habis1 == $tgl_skrg) {
										echo "<font color=#FF0000>User : " . $serv->uservpn . " (H-1 Expired)</font><hr>";
									} elseif ($tgl_habis0 == $tgl_skrg) {
										echo "<font color=#FF0000>User : " . $serv->uservpn . " (Expired Hari ini)</font><hr>";
									}
									else {
									echo '';
									}
								?>
								<?php } ?>
							</div>
						</div>
					</a>
				</div>
			</div>
		</li>
		<li class="dropdown"><a href="#" data-toggle="dropdown"><i class="fa fa-ellipsis-v"></i></a>
			<div class="dropdown-menu lg pull-right arrow panel panel-default arrow-top-right">
				<div class="panel-heading">
					Menu
				</div>
				<div class="panel-body text-center">
					<div class="row">
						<div class="col-xs-4 col-sm-4">
							<a href="dashboard.php" class="text-green">
								<span class="h2"><i class="fa fa-home"></i></span>
								<p class="text-gray no-margn">Beranda</p>
							</a>
						</div>
						<div class="col-xs-4 col-sm-4">
							<a href="pesan.php" class="text-blue">
								<span class="h2"><i class="fa fa-envelope-o"></i></span>
								<p class="text-gray no-margn">Pesan</p>
							</a>
						</div>
						<div class="col-xs-4 col-sm-4">
							<a href="server-member.php" class="text-red">
								<span class="h2"><i class="fa fa-database"></i></span>
								<p class="text-gray no-margn">Server Member</p>
							</a>
						</div>
						<div class="col-xs-12 visible-xs-block"><hr></div> <!-- Only Mobile -->
						<div class="col-lg-12 col-md-12 col-sm-12 hidden-xs"><hr></div> <!-- Only Desktop -->
						<div class="col-xs-4 col-sm-4">
							<a href="server-reseller.php" class="text-yellow">
								<span class="h2"><i class="fa fa-database"></i></span>
								<p class="text-gray no-margn">Server Reseller</p>
							</a>
						</div>
						<div class="col-xs-4 col-sm-4">
							<a href="server-trial.php" class="text-green">
								<span class="h2"><i class="fa fa-database"></i></span>
								<p class="text-gray no-margn">Server Trial</p>
							</a>
						</div>
						<div class="col-xs-4 col-sm-4">
							<a href="akun-member.php" class="text-blue">
								<span class="h2"><i class="fa fa-terminal"></i></span>
								<p class="text-gray no-margn">Akun Member</p>
							</a>
						</div>
						<div class="col-xs-12 visible-xs-block"><hr></div> <!-- Only Mobile -->
						<div class="col-lg-12 col-md-12 col-sm-12 hidden-xs"><hr></div> <!-- Only Desktop -->
						<div class="col-xs-4 col-sm-4">
							<a href="akun-reseller.php" class="text-red">
								<span class="h2"><i class="fa fa-terminal"></i></span>
								<p class="text-gray no-margn">Akun Reseller</p>
							</a>
						</div>
						<div class="col-xs-4 col-sm-4">
							<a href="tambah-saldo.php" class="text-yellow">
								<span class="h2"><i class="fa fa-money"></i></span>
								<p class="text-gray no-margn">Tambah Saldo</p>
							</a>
						</div>
						<div class="col-xs-4 col-sm-4">
							<a href="unduh-config.php" class="text-green">
								<span class="h2"><i class="fa fa-download"></i></span>
								<p class="text-gray no-margn">Unduh Config</p>
							</a>
						</div>
						<div class="col-xs-12 visible-xs-block"><hr></div> <!-- Only Mobile -->
						<div class="col-lg-12 col-md-12 col-sm-12 hidden-xs"><hr></div> <!-- Only Desktop -->
						<div class="col-xs-4 col-sm-4">
							<a href="profile.php" class="text-blue">
								<span class="h2"><i class="fa fa-user"></i></span>
								<p class="text-gray no-margn">Edit Profile</p>
							</a>
						</div>
						<div class="col-xs-4 col-sm-4">
							<a href="kontak.php" class="text-red">
								<span class="h2"><i class="fa fa-phone-square"></i></span>
								<p class="text-gray no-margn">Kontak Admin</p>
							</a>
						</div>
						<div class="col-xs-4 col-sm-4" style="padding-bottom:10px">
							<a href="logout.php" class="text-yellow">
								<span class="h2"><i class="fa fa-sign-out"></i></span>
								<p class="text-gray no-margn">Keluar</p>
							</a>
						</div>
					</div>
				</div>
			</div>
		</li>
	</ul>
</header>