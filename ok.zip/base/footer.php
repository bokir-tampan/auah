<footer class="container-fluid footer">
   <?php
	$qtsite = "SELECT * FROM site";
	$tsite = $databaseConnection->prepare($qtsite);
	$tsite->execute();
	$site = $tsite->fetchAll();
	foreach ($site as $site) 
	?>
   Copyright &copy; 2021 
   <?php
		if($site['url'] == '') {
		 echo '<a href="index.php" target="_blank"><b>' . $site['name'] . '</b></a>';
		} else {
		echo '<a href="' . $site['url'] . '" target="_blank"><b>' . $site['name'] . '</b></a></li>';
		}
	?>
   <a href="#" class="pull-right scrollToTop"><i class="fa fa-chevron-up"></i></a>
</footer>