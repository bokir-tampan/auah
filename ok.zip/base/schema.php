<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Login Area Premium SSH Panel">
<meta name="keywords" content="Premium SSH Panel">
<meta name="author" content="fornesia.com">
<link rel="icon" href="images/brand.png" sizes="32x32">