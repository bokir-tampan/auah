<?php
ob_start();
session_start();
include 'asset/css/config.php';
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');
$waktu1 = date('Y-m-d h:i:s');
$habis1 = date('Y-m-d', strtotime($tgl. ' + 1 days'));

$qdariserver = "SELECT * FROM server WHERE idserver = :idserver";
$dariserver = $databaseConnection->prepare($qdariserver);
$dariserver->bindParam(':idserver', $_REQUEST['idserver']);
$dariserver->execute();

while($tampilserver = $dariserver->fetch(PDO::FETCH_OBJ)){

if(isset($_POST['enter'])) {
	$dari = $_POST['dari'];
	$uservpn = $_POST['uservpn'];
	$passvpn = $_POST['passvpn'];
	$idserver = $tampilserver->idserver;
	$host = $tampilserver->host;
	$lokasi = $tampilserver->lokasi;
	$isp = $tampilserver->isp;
	$openssh = $tampilserver->openssh;
	$dropbear = $tampilserver->dropbear;
	$squid = $tampilserver->squid;
	$ovpn = $tampilserver->ovpn;
	$link_config = $tampilserver->link_config;
	$catatan = $tampilserver->catatan;
	$type = '/bin/false -m';
	$username = $_POST['namauservpn'];
	$saldo = $_POST['saldo'];
	$kode = $_POST['kode'];
	//Harga Akun
	$harga1 = 1;
	//Total
	$total1 = $saldo-$harga1;
	//Kurang
	$kurang1 = $saldo<$harga1;
	$habis = $_POST['habis'];
	$namaserver = $tampilserver->namaserver;
	//Log
	$usernamelog = $_POST['namauservpn'];
	$namaserverlog = $tampilserver->namaserver;
	$uservpnlog = $_POST['uservpn'];
	$habislog = $_POST['habis'];
	$darilog = $_POST['dari'];
	$kodelog = $_POST['kode'];
	$waktulog = $_POST['waktu'];
	
	$connection = ssh2_connect($tampilserver->host, 22);
	$qorder = "SELECT uservpn, host FROM akun WHERE uservpn = :uservpn AND host = :host";
	$order = $databaseConnection->prepare($qorder);
	$order->bindParam(':uservpn', $uservpn);
	$order->bindParam(':host', $host);
	$order->execute();
	
	
	if($kurang1) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Anda tidak mempunyai akses pembuatan akun trial.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah Saldo</a> Reseller.</p>
				</div>
			';
			}
	elseif($order->rowCount() > 0){
		if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
			$result = ssh2_exec($connection, "{ echo $passvpn; echo $passvpn; } | passwd $uservpn;");
			
			//update
			$qubahpass = "UPDATE akun SET passvpn = :passvpn, dari = :dari WHERE uservpn = :uservpn";
			$ubahpass = $databaseConnection->prepare($qubahpass);
			$ubahpass->bindParam(':passvpn', $passvpn);
			$ubahpass->bindParam(':dari', $dari);
			$ubahpass->bindParam(':uservpn', $_POST['uservpn']);
			$ubahpass->execute();
			
			//history
			$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
			$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
			$simpanakun2->bindParam(':username', $usernamelog);
			$simpanakun2->bindParam(':namaserver', $namaserverlog);
			$simpanakun2->bindParam(':uservpn', $uservpnlog);
			$simpanakun2->bindParam(':expiredate', $habislog);
			$simpanakun2->bindParam(':dari', $darilog);
			$simpanakun2->bindParam(':kode', $kodelog);
			$simpanakun2->bindParam(':waktu', $waktulog);
			$simpanakun2->execute();
		
			$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Detail Akun Trial!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis1.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
		else {
			$gagal = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Gagal Buat Trial Akun!</h4>
				<p>Ada Masalah Pada Server</p>
				<hr>
				<p class="mb-0">Silahkan Hubungi Admin.</p>
				</div>
			';
			}
	}
		//Trial 1 Hari
		else {
			if (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '1 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Detail Akun Trial!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis1.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}
		}

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Trial Akun</title>
</head>

<body>

	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>

        <div class="warper container-fluid">
			<?php 
			if ($tampilserver->status3 == "Tersedia") {
			?>
			<div class="page-header"><center><h3><i class="fa fa-fw fa-database"></i> <?php echo $tampilserver->namaserver; ?></h3></center></div>
            <div class="row">
				<div class="col-md-6" style="padding-left:0;padding-right:0">
					<div class="col-md-6">
						<div class="panel panel-default">
							<div class="panel-heading"><center>Akses Trial</center></div>
							<div class="panel-body">
								<div class="form-group">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-clock-o fa-fw"></i></span>
										<input type="text" class="form-control" value="<?php if($deposit['balance3'] == 1) {
											echo "Ya";
										} else {
											echo "Tidak";
										}
										
										
										?>" readonly />
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="panel panel-default">
							<div class="panel-heading"><center>Harga</center></div>
							<div class="panel-body">
								<div class="form-group">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-money fa-fw"></i></span>
										<input type="text" class="form-control" value="Gratis" readonly />
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="panel panel-default">
							<div class="panel-heading"><center>Catatan</center></div>
							<div class="panel-body">
								<div class="form-group">
									<center><b>Lakukan Pembuatan Akun trial jika ada pemintaan langsung dari calon pembeli.</b><hr></center>
								</div>
							</div>
						</div>
					</div>
				</div>
            	<div class="col-md-6">
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
					<?php if(isset($gantiusername)){ echo $gantiusername; } ?>
					<?php if(isset($saldokurang)){ echo $saldokurang; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
					<?php if(isset($pilih)){ echo $pilih; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><center>Buat Trial Akun</center></div>
                        <div class="panel-body">
                        	<form  method="post" action="">
							<input type="hidden" class="form-control" name="namauservpn" value="trial-akun" readonly />
							<input type="hidden" name="dari" value="<?php echo $menuusername; ?>" readonly />
							<input type="hidden" name="kode" value="0" readonly />
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-user fa-fw"></i></span>
									<input type="text" class="form-control" name="uservpn" value="<?php echo $tampilserver->trial;?>" readonly />
								</div>
							</div>
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-key fa-fw"></i></span>
									<input type="text" class="form-control" name="passvpn" value="<?php include 'base/random.php'; ?>" readonly />
								</div>
							</div>
                            <div class="form-group">
								<div class="input-group">
									<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
									<input type="text" class="form-control" name="habis" value="<?php echo $habis1; ?>" readonly />
									<input type="hidden" class="form-control" name="waktu" value="<?php echo $waktu1; ?>" readonly />
								</div>
                            </div>
							<input type="hidden" class="form-control" name="saldo" value="<?php 
							$qdarimember = "SELECT balance3 FROM member WHERE email = :email";
							$darimember = $databaseConnection->prepare($qdarimember);
							$darimember->bindParam(':email', $menuusername);
							$darimember->execute();
							while($tampilmember=$darimember->fetch(PDO::FETCH_OBJ)){
								echo $tampilmember->balance3;
								}
							 ?>"/>
							 
                            <hr class="dotted">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary" id="enter" name="enter" value="enter">
									<i class="fa fa-clock-o fa-fw"></i> Buat Akun
								</button>
                                <a href="server-trial.php">
									<button type="button" class="btn btn-danger" id="resetBtn"><i class="fa fa-arrow-circle-left fa-fw"></i> Kembali</button>
								</a>
                            </div>
                            </form>
                        </div>
                    </div>
				</div>
			</div>
			<?php } } ?>
    </section>
    <section class="content">
		<?php include 'base/footer.php'; ?>
	</section>

    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>