<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Akun SSH</title>
</head>

<body>	



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
	
		<?php include 'base/header.php'; ?>
		
        <div class="warper container-fluid">
			<div class="page-header"><center><h3><i class="fa fa-fw fa-terminal"></i> Akun SSH</h3></center></div>
			<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading"><i class="fa fa-fw fa-terminal"></i> Akun SSH</div>
					<div class="panel-body">
						<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
							<thead>
								<tr>
									<th>Nama Server</th>
									<th>Host</th>
									<th>Username</th>
									<th>Masa Aktif</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$qtserver = "SELECT * FROM akun WHERE username = :pengguna";
								$tserver = $databaseConnection->prepare($qtserver);
								$tserver->bindParam(':pengguna', $menuusername);
								$tserver->execute();
								while ($serv = $tserver->fetch(PDO::FETCH_OBJ)) {
								?>
								<tr class="odd gradeX">
									<td><?php echo $serv->namaserver; ?></td>
									<td><?php echo $serv->host; ?></td>
									<td><?php echo $serv->uservpn; ?></td>
									<td>
										<?php 
										$habis = $serv->expiredate; 
										$tgl_habis = strtotime($habis);
										$tgl_habis1 = strtotime($habis . ' - 1 Days');
										$tgl_habis2 = strtotime($habis . ' - 2 Days');
										$tgl_habis3 = strtotime($habis . ' - 3 Days');
										$tgl_habis4 = strtotime($habis . ' - 4 Days');
										$tgl_habis5 = strtotime($habis . ' - 5 Days');
										$tgl_skrg = strtotime($tgl);

										if ($tgl_habis < $tgl_skrg) {
											echo "<font color=#FF0000>Akun Expired</font>";
											}
											elseif ($tgl_habis == $tgl_skrg) {
												echo $habis . '<font color=#ff8d00> (Expired Hari ini)</font>';
											}
											elseif ($tgl_habis1 == $tgl_skrg) {
												echo $habis . '<font color=#ff8d00> (Expired 1 Hari Lagi)</font>';
											}
											elseif ($tgl_habis2 == $tgl_skrg) {
												echo $habis . '<font color=#ff8d00> (Expired 2 Hari Lagi)</font>';
											}
											elseif ($tgl_habis3 == $tgl_skrg) {
												echo $habis . '<font color=#ff8d00> (Expired 3 Hari Lagi)</font>';
											}
											elseif ($tgl_habis4 == $tgl_skrg) {
												echo $habis . '<font color=#ff8d00> (Expired 4 Hari Lagi)</font>';
											}
											elseif ($tgl_habis5 == $tgl_skrg) {
												echo $habis . '<font color=#ff8d00> (Expired 5 Hari Lagi)</font>';
											}
											else {
											echo "<font color=#0F9D28>" . $habis . "</font>";
											}
										?>
									</td>
									<td>
										<a href="change.php?id=<?php echo $serv->id; ?>" title="Ganti Password">
											<button class="btn btn-warning"><i class="fa fa-key"></i></button>
										</a>
										<a href="renew.php?id=<?php echo $serv->id; ?>" title="Renew Akun">
											<button class="btn btn-info"><i class="fa fa-calendar"></i></button>
										</a>
										<a href="detail.php?id=<?php echo $serv->id; ?>" title="Detail Akun">
											<button class="btn btn-success"><i class="fa fa-user"></i></button>
										</a>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			</div>
		</div>

		<?php include 'base/footer.php'; ?>

    </section>
	

    
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
   
</body>

</html>