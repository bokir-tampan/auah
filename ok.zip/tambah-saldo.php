<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');
$habis = date('Y-m-d', strtotime($tgl. ' + 30 days'));

if(isset($_POST['upload'])) {
	$nama_pengirim = $_POST['nama_pengirim'];
	$email = $_POST['email'];
	$sname = $_POST['sname'];
	$sadmin = $_POST['sadmin'];
	$surl = $_POST['surl'];
	$saldo = $_POST['saldo'];
	$total = $_POST['total'];
	$via = $_POST['via'];
	$file = addslashes(rand(1,10)."-".$_FILES['screenshot']['name']);
	$type = addslashes($_FILES['screenshot']['type']);
	
	$qorder = "SELECT * FROM payment WHERE buktitransfer = :buktitransfer";
	$order = $databaseConnection->prepare($qorder);
	$order->bindParam(':buktitransfer', $file);
	$order->execute();
	
	if($saldo == "Silahkan Pilih") {
		$berhasil = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Kirim Bukti Transfer Gagal!</h4>
			<p>Jenis Saldo belum Anda Pilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
			';
	}
	elseif($via == "Silahkan Pilih") {
		$berhasil = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Kirim Bukti Transfer Gagal!</h4>
			<p>Pembayaran belum Anda Pilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
			';
	}
	
	elseif($order->rowCount() > 0){
		$berhasil = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Gagal Upload Bukti Transfer!</h4>
			<p>Bukti Transfer Sudah Pernah Di Upload.</p>
			<hr>
			<p class="mb-0">Silahkan Coba Kembali.</p>
			</div>
		';
	}
	
	// Simpan di Folder Gambar
	elseif($type == "image/png" || $type=="image/jpeg" || $type=="image/pjpeg" || $type == "image/jpg" || $type == "image/gif" || $type == "image/x-png") {
	// SMTP Mailer
	require_once('function.php');
	$to       = $sadmin;
	$subject  = "Informasi Penambahan Saldo";
	// Message SMTP Mailer
	$message  = "
	<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;margin-to:15px;border-top:1px solid #eee;font-size:16px'><b>Permintaan Tambah Saldo | ".$sname."</b></div>
	<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
		<tbody>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px;width:100px'>Email</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$email."</th>
			<tr>
			<tr>
				<td style='padding:8px 10px'>Nama Pengirim</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$nama_pengirim."</th>
			</tr>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px;width:100px'>Jenis Saldo</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$saldo."</th>
			<tr>
			<tr>
				<td style='padding:8px 10px'>Nominal Transfer</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".number_format($total, 0 , '' , '.' )."</th>
			</tr>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px'>Pembayaran Via</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$via."</th>
			</tr>
			<tr>
				<td style='padding:8px 10px'>Bukti Transfer</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'><a href='".$surl."/screenshot/".$file."' target='_blank'><b>".$file."</b></a></th>
			</tr>
		</tbody>
	</table>
	";
	$from_name = 'no reply';
	$from = 'noreply@fornesia.com';
	smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
	
	// SMTP Mailer
	require_once('function2.php');
	$to       = $email;
	$subject  = "Informasi Penambahan Saldo";
	// Message SMTP Mailer
	$message  = "
	<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;margin-to:15px;border-top:1px solid #eee;font-size:16px'><b>Anda Telah Melakukan Permintaan Tambah Saldo | ".$sname."</b></div>
	<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
		<tbody>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px;width:100px'>Email</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$email."</th>
			<tr>
			<tr>
				<td style='padding:8px 10px'>Nama Pengirim</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$nama_pengirim."</th>
			</tr>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px;width:100px'>Jenis Saldo</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$saldo."</th>
			<tr>
			<tr>
				<td style='padding:8px 10px'>Nominal Transfer</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".number_format($total, 0 , '' , '.' )."</th>
			</tr>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px'>Pembayaran Via</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$via."</th>
			</tr>
			<tr>
				<td style='padding:8px 10px'>Bukti Transfer</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'><a href='".$surl."/screenshot/".$file."' target='_blank'><b>".$file."</b></a></th>
			</tr>
		</tbody>
	</table>
	";
	$from_name = 'no reply';
	$from = 'noreply@fornesia.com';
	smtp_mail2($to, $subject, $message, $from_name, $from, 0, 0, false);
	
	$qsimpan = "INSERT INTO payment SET nama_pengirim = :nama_pengirim, email = :email, saldo = :saldo, total = :total, via = :via, buktitransfer = :buktitransfer";
	$hsimpan = $databaseConnection->prepare($qsimpan);
	$hsimpan->bindParam(':nama_pengirim', $nama_pengirim);
	$hsimpan->bindParam(':email', $email);
	$hsimpan->bindParam(':saldo', $saldo);
	$hsimpan->bindParam(':via', $via);
	$hsimpan->bindParam(':total', $total);
	$hsimpan->bindParam(':buktitransfer', $file);
	$hsimpan->execute();
	
	move_uploaded_file($_FILES['screenshot']['tmp_name'], "screenshot/".$file);
	$berhasil = '
	<div class="alert alert-success" role="alert">
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
	<h4 class="alert-heading">Permintaan Tambah Saldo Berhasil!</h4>
	<p>Nama Pengirim : '.$nama_pengirim.'</p>
	<p>Email : '.$email.'</p>
	<p>Jenis Saldo : '.$saldo.'</p>
	<p>Pembayaran Via : '.$via.'</p>
	<p>Jumlah Transfer : '.number_format($total, 0 , '' , '.' ).'</p>
	<p>Bukti Transfer : <a href="screenshot/'.$file.'" target="_blank"><b>'.$file.'</b></a></p>
	<hr>
	<p class="mb-0">Pastikan Jumlah Transfer dan Bukti Transfer Sesuai.<br>Jika Anda terindikasi berbohong, akun Kami Kunci.</p>
	</div>
	';
	}
	else {
		$berhasil = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Gagal Upload Bukti Transfer!</h4>
			<p>Tipe Gambar <b><i>'.$type.'</i></b> Tidak Dikenal.</p>
			<p>Pastikan Gambar bereksistensi jpg/jpeg/png.</p>
			<hr>
			<p class="mb-0">Silahkan Coba Kembali.</p>
			</div>
		';
	}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling -->
<link rel="stylesheet" href="asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts -->


<!-- Base Styling -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Tambah Saldo</title>

<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
<script src="asset/js/input.js" type="text/javascript"></script>

</head>

<body>	



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
		
        <div class="warper container-fluid">
			
			<div class="page-header"><center><h3><i class="fa fa-fw fa-money"></i> Tambah Saldo</h3></center></div>
			
			<!-- Upload Bukti Transfer -->
			<div class="row">
				<div class="col-md-6">
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
                	<div class="panel panel-default" style="min-height:25.9pc;">
                        <div class="panel-heading"><center>Kirim Bukti Transfer</center></div>
						<div class="panel-body">
							<form  method="post" class="validator-form" action="" enctype="multipart/form-data">
								<div class="form-group">
									<?php
									$qtsite = "SELECT * FROM site";
									$tsite = $databaseConnection->prepare($qtsite);
									$tsite->execute();
									$site = $tsite->fetchAll();
									foreach ($site as $site)
									$sadmin = $site['email'];
									$surl = $site['url'];
									$sname = $site['name'];
									?>
									<input type="hidden" class="form-control" name="sadmin" value="<?php echo $sadmin; ?>" readonly />
									<input type="hidden" class="form-control" name="surl" value="<?php echo $surl; ?>" readonly />
									<input type="hidden" class="form-control" name="sname" value="<?php echo $sname; ?>" readonly />
									<input type="hidden" class="form-control" name="email" value="<?php echo $menuusername; ?>" readonly />
									<small>Nama Pemilik Rekening atau No HP (Jika Transfer Pulsa) :</small>
									<div class="input-group">
										<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-user fa-fw"></i></span>
										<input type="text" class="form-control" name="nama_pengirim" required >
									</div>
									
								</div>
								<div class="form-group">
									<small>Pilih Jenis Saldo :</small>
									<div class="input-group">
										<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-money fa-fw"></i></span>
										<select type="text" class="form-control" name="saldo">
										    <option>Silahkan Pilih</option>
										    <option>Member</option>
										    <option>Reseller</option>
									    </select>
									</div>
								</div>
								<div class="form-group">
									<small>Nominal Transfer :</small>
									<div class="input-group">
										<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calculator fa-fw"></i></span>
										<input type="number" class="form-control" name="total" required />
									</div>
								</div>
								<div class="form-group">
									<small>Pembayaran Via :</small>
									<div class="input-group">
										<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-cc fa-fw"></i></span>
										<select type="text" class="form-control" name="via">
										    <option>Silahkan Pilih</option>
										    <option>Pulsa XL</option>
										    <option>Pulsa Tsel</option>
										    <option>Bank BRI</option>
									    </select>
									</div>
								</div>
								<div class="form-group">
									<small>Bukti Transfer :</small>
									<div class="input-group">
										<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-file fa-fw"></i></span>
										<input type="file" class="form-control" name="screenshot" required />
									</div>
								</div>
								<hr class="dotted">
								<div class="col-md-6">
									<div class="form-group">
										<button type="submit" class="btn btn-primary" id="upload" name="upload" style="width:100%">
											<i class="fa fa-upload fw"></i> Upload Screenshot
										</button>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<button type="reset" class="btn btn-danger" id="resetBtn" style="width:100%">
											<i class="fa fa-trash fw"></i> Reset
										</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-md-6">
                	<div class="panel panel-default" style="min-height:30pc;">
                        <div class="panel-heading"><center>Informasi Deposit</center></div>
						<div class="panel-body" style="height:18.3pc">
							<?php
								$qtinformasi = "SELECT * FROM informasi";
								$tinformasi = $databaseConnection->prepare($qtinformasi);
								$tinformasi->execute();
								$informasi = $tinformasi->fetchAll();
								foreach ($informasi as $info)
									
							?>
							<textarea style="resize: none;width:100%;height:150%;border:none;background:none;" disabled ><?php
							if($info['deposit'] == '') {
							 echo '';
							} else {
							echo $info['deposit'];
							}
							?></textarea>
						</div>
					</div>
				</div>
			</div>

			<!-- Daftar Upload Bukti Transfer -->
			<div class="row">
				<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading"><center>Daftar Upload Bukti Transfer</center></div>
						<div class="panel-body">
							<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
								<thead>
									<tr>
										<th>Pengirim</th>
										<th>Jenis Saldo</th>
										<th>Jumlah Transfer</th>
										<th>Via</th>
										<th>Bukti Transfer</th>
										<th>Keterangan</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$qtserver = "SELECT * FROM payment WHERE email = :pengguna";
									$tserver = $databaseConnection->prepare($qtserver);
									$tserver->bindParam(':pengguna', $menuusername);
									$tserver->execute();
									while ($serv = $tserver->fetch(PDO::FETCH_OBJ)) {
									?>
									<tr class="odd gradeX">
										<td><?php echo $serv->nama_pengirim; ?></td>
										<td><?php echo $serv->saldo; ?></td>
										<td>Rp. <?php echo $serv->total; ?></td>
										<td><?php echo $serv->via; ?></td>
										<td><a href="screenshot/<?php echo $serv->buktitransfer; ?>" target="_blank"><?php echo $serv->buktitransfer; ?></a></td>
										<td>
											<?php if($serv->lunas == "Tidak") { ?>
												<a href="#" onclick="deletepayment(<?php echo $serv->id;?>)" class="btn btn-danger" title="Delete">
													<i class="fa fa-trash fa-fw"></i> Hapus
												</a>
											<?php } else { ?>
											<button class="btn btn-success" disabled >
												<i class="fa fa-check fa-fw"></i> Sukses
											</button>
											<?php } ?>
										</td>
									 </tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
				</div>
				</div>
			</div>

		</div>

		<?php include 'base/footer.php'; ?>
		
    </section>
	
    <!-- start: JavaScript-->
	<script type="text/javascript">
	function deletepayment(id) {
		var answer = confirm('Anda yakin?')
		if(answer) {
			window.location = 'deletepayment.php?id=' +id;
			}
		}
	</script>
	
    <script id="jsbin-javascript">
		$("input").on("keypress",function(e){
		var val = $(this).val();
		var open = val.indexOf('<');
		var close = val.indexOf('>');
		if(open!==-1 && close!==-1) {
		$(this).val(val.replace(val.slice(open,close+1),""));
		}
		});
	</script>
	
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
   
</body>

</html>