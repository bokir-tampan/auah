<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
// Waktu Pendaftaran
$waktu1 = date('Y-m-d h:i:s');
// Waktu Jatuh Tempo
$waktu2 = date('Y-m-d', strtotime($waktu1. ' + 5 days'));

// Ambil URL Web
$id = "1";
$qce = "SELECT * FROM site WHERE id = :id";
$ce = $databaseConnection->prepare($qce);
$ce->bindParam(':id', $id);
$ce->execute();
while ($cee = $ce->fetch(PDO::FETCH_OBJ)) {
	$url = $cee->url;
	$emailadmin = $cee->email;
}
// Kode Validasi
function passFunc2($len2, $set2 = "") {
$gen2 = "";
	for($i=0;$i<$len2;$i++) {
	$set2 = str_shuffle($set2);
	$gen2 .= $set2[0];
	}
return $gen2;
}
$passcode2=passFunc2(50,'abcdefghijklmnopqrstuvwxyzABCDEFGHIZKLMNOPQRSTUVWXYZ123456789');
// Klik Daftar
if(isset($_POST['tambah'])) {
	
	$nama = $_POST['nama'];
	$username = $_POST['namauser'];
	$password = password_hash($_POST['password'], PASSWORD_DEFAULT, ['cost' => 12,]);
	$passwordtext = $_POST['password'];
	$email = $_POST['email'];
	$jk = $_POST['jk'];
	$kota = $_POST['kota'];
	$prov = $_POST['prov'];
	$nohp = $_POST['nohp'];
	$balance1 = 0;
	$balance2 = 0;
	$balance3 = 0;
	$status = "Pending";
	$validasi = $passcode2;
	$waktu = $waktu1;
	$url = $url;
	// Pilih Database
	$qcek = "SELECT * FROM member WHERE username = :username";
	$cek = $databaseConnection->prepare($qcek);
	$cek->bindParam(':username', $username);
	$cek->execute();
	// cek username tersedia/tidak
	if($cek->rowCount() > 0) {
		$errormsg = "<b>Username sudah digunakan, silahkan ganti dengan yang lain.</b><hr>";
	}
	// cek email tersedia/tidak
	elseif($email != ''){
	$qcek2 = "SELECT * FROM member WHERE email = :email";
	$cek2 = $databaseConnection->prepare($qcek2);
	$cek2->bindParam(':email', $email);
	$cek2->execute();
		if($cek2->rowCount() > 0) {
		$errormsg = '
		<div class="alert alert-danger" role="alert">
			<center><b>Email sudah digunakan, silahkan ganti dengan yang lain.</b></center>
		</div>';
		}
		// cek nohp tersedia/tidak
		elseif($nohp != '0'){
		$qcek3 = "SELECT * FROM member WHERE nohp = :nohp";
		$cek3 = $databaseConnection->prepare($qcek3);
		$cek3->bindParam(':nohp', $nohp);
		$cek3->execute();
			if($cek3->rowCount() > 0) {
			$errormsg = '
			<div class="alert alert-danger" role="alert">
			<center><b>Nomor Handphone sudah digunakan, silahkan ganti dengan yang lain.</b></center>
			</div>';
			}
			// cek kuota member
			elseif($username != '' && $email != '' && $nohp != ''){
			$hitung = $databaseConnection->prepare("SELECT COUNT(*) FROM member");
			$hitung->execute();
			$num_rows = $hitung->fetchColumn();
				if($num_rows == 1000) {
				$errormsg = '
				<div class="alert alert-danger" role="alert">
				<center><b>Pendaftaran tidak bisa dilakukan, silahkan Hubungi Admin.</b></center>
				</div>';
				}
				// berhasil
				else {
				// kirim email
				require_once('function.php');
				$to       = $email;
				$subject  = 'Konfirmasi Pendaftaran';
				$message  = '
				<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody>
				<tr>
				<td bgcolor="#f2f2f2" style="font-size:0px">&nbsp;</td>
				<td bgcolor="#ffffff" width="660" align="center">
				<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody>
				<tr>
				<td align="center" width="600" valign="top">
				<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<tbody>
				<tr>
				<td bgcolor="#f2f2f2" style="padding-top:10px"></td>
				</tr>
				<tr>
				<td bgcolor="#f2f2f2" style="padding-top:10px"></td>
				</tr>
				<tr>
				<td align="center" valign="top" bgcolor="#ffffff">
				<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:10px;padding-top:20px" width="100%">
				<tbody>
				<tr valign="bottom">    
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td>
				<span>
				<b>KONFIRMASI PENDAFTARAN</b>
				</span>                                
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>
				</tr>
				</tbody>
				</table>
				<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:10px;padding-top:10px;margin-bottom:10px" width="100%">
				<tbody>
				<tr valign="bottom">    
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td valign="top" style="font-family:Calibri,Trebuchet,Arial,sans serif;font-size:15px;line-height:22px;color:#333333">
				<p>Yth. <a href="mailto:'.$email.'" target="_blank">'.$nama.'</a>,
				<br>Untuk melakukan aktifasi akun, silahkan klik link berikut :<br>'.$url.'/aktifasi/?id='.$validasi.'</p>
				<p>
				<b>Detail Registrasi</b><br>
				Nama Lengkap : '.$nama.'<br>
				Username : '.$username.'<br>
				Email : '.$email.'<br>
				Password : '.$passwordtext.'<br>
				No HP : '.$nohp.'<br>
				Jenis Kelamin : '.$jk.'<br>
				Kota/Kab : '.$kota.'<br>
				Provinsi : '.$prov.'<br>
				Saldo Member : '.$balance1.'<br>
				Saldo Reseller : '.$balance2.'<br>
				Status : '.$status.'<br>
				Waktu Pendaftaran : '.$waktu.'<br>
				<br><br>Salam Hormat,<br>Admin
				</p>
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>
				</tr>
				</tbody>
				</table>
				</td>
				</tr>
				</tbody>
				</table>
				</td>
				</tr>
				</tbody>
				</table>
				<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody>
				<tr>
				<td align="center" width="600" valign="top">
				<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<tbody>
				<tr>
				<td bgcolor="#f2f2f2" style="padding-top:20px"></td>
				</tr>
				<tr>
				<td align="center" valign="top" bgcolor="#f2f2f2">
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody>
				<tr valign="bottom">   
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td>
				<table align="left" border="0" cellpadding="0" cellspacing="0">
				<tbody>
				<tr>
				<td style="font-family:Calibri,Trebuchet,Arial,sans serif;font-size:13px;color:#666;font-weight:bold">
				<span id="m_-6118667421211539915bottomLinks">
				<div style="margin:5px 0;padding:0">
				<span style="display:inline">
				<span>
				<a href="https://www.fornesia.com" style="text-decoration:none" target="_blank">
				Bantuan&nbsp;
				</a>
				</span>
				<span style="color:#ccc"><span> | </span></span>
				<span>
				<a href="https://www.fornesia.com" style="text-decoration:none" target="_blank" >
				Webiste&nbsp;
				</a>
				</span>
				</span>
				</div>
				</span>
				</td>
				</tr>
				</tbody>
				</table>
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>    
				</tr>
				</tbody>
				</table>           
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody>
				<tr valign="bottom">   
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td>
				<p> Jangan balas ke email ini. Untuk menghubungi kami, klik 
				<strong><a href="" style="text-decoration:none" target="_blank" >Bantuan dan Hubungi</a></strong>.
				</p>
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>
				</tr>
				</tbody>
				</table>  
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody>
				<tr valign="bottom">   
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td>
				<span>  
				<table border="0" cellpadding="0" cellspacing="0" id="m_-6118667421211539915emailFooter" style="padding-top:10px;font:12px Arial,Verdana,Helvetica,sans-serif;color:#292929" width="100%">
				<tbody>
				<tr>
				<td>
				<p>Hak Cipta © 2021 fornesia.com</p>
				</td>
				</tr>
				</tbody>
				</table>
				</span>
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>    
				</tr>
				</tbody>
				</table>    

				</td>
				</tr>
				</tbody>
				</table>
				</td>

				</tr>
				</tbody>
				</table>
				</td>
				<td bgcolor="#f2f2f2" style="font-size:0px">&nbsp;</td>
				</tr>
				</tbody>
				</table>
				';
				$from_name = 'no reply';
				$from = 'noreply@fornesia.com';
				smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
				
				// input ke database
				$quser = "INSERT INTO member SET nama = :nama, username = :username, password = :password, email = :email, jk = :jk, kota = :kota, prov = :prov, nohp = :nohp, balance1 = :balance1, balance2 = :balance2, balance3 = :balance3, status = :status, validasi = :validasi, waktu = :waktu";
				$exuser = $databaseConnection->prepare($quser);
				$exuser->bindParam(':nama', $nama);
				$exuser->bindParam(':username', $username);
				$exuser->bindParam(':password', $password);
				$exuser->bindParam(':email', $email);
				$exuser->bindParam(':jk', $jk);
				$exuser->bindParam(':kota', $kota);
				$exuser->bindParam(':prov', $prov);
				$exuser->bindParam(':nohp', $nohp);
				$exuser->bindParam(':balance1', $balance1);
				$exuser->bindParam(':balance2', $balance2);
				$exuser->bindParam(':balance3', $balance3);
				$exuser->bindParam(':status', $status);
				$exuser->bindParam(':validasi', $validasi);
				$exuser->bindParam(':waktu', $waktu);
				$exuser->execute();
				$successmsg = '
				<div class="alert alert-success" role="alert">
				<center>
				<b>Registrasi berhasil!</b><br>
				Silahkan cek Emai atau lihat <span class="text-danger">folder spam</span> email Anda untuk Aktifasi.<br>
				</center>
				</div>
				';
				}
			}
		}
	}
	
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<title>Daftar Akun</title>

<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>

<body style="background-color:#121215">
	<center>
        <div class="warper container-fluid" style="padding: 0;margin:0;min-height:300px;max-width:600px;">
			<div class="row" style="margin:auto">
            	<div class="col-md-12">
				<div class="page-header" style="margin:25px 0 25px"><h1>Form Pendaftaran Member</h1></div>
                	<div class="panel panel-default">
                        <div class="panel-heading">Isi Data diri Anda dengan Benar</div>
                        <div class="panel-body">
							<span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
							<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                        	<form  method="post" class="validator-form" action="" style="text-align: left">
									<div class="row">
										<div class="col-lg-6">
											<div class="form-group">
											<label class="control-label">Nama Lengkap</label>
											<input type="text" class="form-control" name="nama" placeholder="Ex: Alex Farhan" required/>
											</div>
										</div>
										<div class="col-lg-6">
											<div class="form-group">
											<label class="control-label">Username</label>
											<input type="text" class="form-control" name="namauser" placeholder="Ex: alex" required/>
											</div>
										</div>
								</div>
								
								<div class="row">
									<div class="col-lg-3">
										<div class="form-group">
											<label class="control-label">JK</label>
											<select type="text" class="form-control" name="jk">
												<option>L</option>
												<option>P</option>
											</select>
										</div>
									</div>
									<div class="col-lg-5">
										<div class="form-group">
											<label class="control-label">Kota/Kab</label>
											<input type="text" class="form-control" name="kota" placeholder="Ex: Bandung" required/>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label class="control-label">Provinsi</label>
											<input type="text" class="form-control" name="prov" placeholder="Ex: Jawa Barat" required/>
										</div>
									</div>
								</div>
									<div class="row">
										<div class="col-lg-6">
											<div class="form-group">
											<label class="control-label">Email</label>
											<input type="text" class="form-control" name="email" placeholder="Ex: namakamu@domain.com" required/>
											</div>
										</div>
										<div class="col-lg-6">
											<div class="form-group">
											<label class="control-label">No Handphone</label>
											<input type="number" class="form-control" name="nohp" placeholder="Ex: 628777777777" required/>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-lg-6">
											<div class="form-group">
											<label class="control-label">Password</label>
											<input type="password" class="form-control" name="password" placeholder="******"/>
											</div>
										</div>
										<div class="col-lg-6">
											<div class="form-group">
											<label class="control-label">Re Password</label>
											<input type="password" class="form-control" name="confirmPassword" placeholder="******"/>
											</div>
										</div>
									</div>
								<hr>
									<div class="col-md-6" style="padding: 2px">
										<div class="form-group">
										<center>
										<button type="submit" class="btn btn-primary" name="tambah" value="Add" style="width :100%">
											DAFTAR
										</button>
										</center>
										</div>
									</div>
									<div class="col-md-6" style="padding: 2px">
										<div class="form-group">
										<center>
										<a href="login.php">
											<button type="button" class="btn btn-success" style="width :100%">
												LOGIN
											</button>
										</a>
										</center>
										</div>
									</div>
								</div>
                            </form>
                        </div>
                    </div>
                 </div>
			</div>
       </div>
    </center>
	<?php
	$qtsite = "SELECT * FROM site";
	$tsite = $databaseConnection->prepare($qtsite);
	$tsite->execute();
	$site = $tsite->fetchAll();
	foreach ($site as $site)
	?>
	<p class="text-center">Copyright 2021 <a href="index.php"><b><?php echo $site['name']; ?></b></a></p>

	
	<script id="jsbin-javascript">
		$("input").on("keypress",function(e){
		var val = $(this).val();
		var open = val.indexOf('<');
		var close = val.indexOf('>');
		if(open!==-1 && close!==-1) {
		$(this).val(val.replace(val.slice(open,close+1),""));
		}
		});
	</script>

    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>