<?php
ob_start();
session_start();
include 'asset/css/config.php';
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
	
	// Ambil Kode Validasi
	$qcek = "SELECT * FROM member WHERE validasi = :id";
	$cek = $databaseConnection->prepare($qcek);
	$cek->bindParam(':id', $_GET['id']);
	$cek->execute();
	
	// Ambil Keterangan Member
	while ($aktifasi = $cek->fetch(PDO::FETCH_OBJ)) {
	$email = $aktifasi->email;
	$nama = $aktifasi->nama;
	$username = $aktifasi->username;
	$jk = $aktifasi->jk;
	$kota = $aktifasi->kota;
	$prov = $aktifasi->prov;
	$balance1 = $aktifasi->balance1;
	$balance2 = $aktifasi->balance2;
	$nohp = $aktifasi->nohp;
	$waktu = $aktifasi->waktu;
	$status = $aktifasi->status;
	}
	
	// Logika jika status aktif dan terkunci
	if($status == "Aktif") {
	$errormsg = '
	<div class="alert alert-danger" role="alert">
	<center><b>Akun Sudah Terverifikasi.</b></center>
	</div>';
	}
	// Logika jika status aktif dan terkunci
	elseif($status == "Kunci") {
	$errormsg = '
	<div class="alert alert-danger" role="alert">
	<center><b>Akun Sudah Terverifikasi.</b></center>
	</div>';
	}
	
	// Logika jika status (member) tidak ada
	elseif($status == "") {
	$errormsg = '
	<div class="alert alert-danger" role="alert">
	<center><b>Link Aktifasi Salah.</b></center>
	</div>';
	}
	// Logika jika status member pending (OK)
	else {
	$qserver = "UPDATE member SET status = :statusbaru, validasi = :validasibaru WHERE email = :email";
	$statusbaru = "Aktif";
	$validasibaru = "Teraktifasi";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':statusbaru', $statusbaru);
	$exserver->bindParam(':validasibaru', $validasibaru);
	$exserver->bindParam(':email', $email);
	$exserver->execute();
	
	$successmsg = '
	<div class="alert alert-success" role="alert">
	<center><b>Akun Anda Sudah Aktif, Silahkan Login.</b><br><br>
	<a href="login.php">
		<button type="button" class="btn btn-success" style="width :100%">
			LOGIN
		</button>
	</a>
	</center>
	</div>';
	}
?>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<title>Aktifasi</title>

<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>

<body style="background-color:#121215">
	<center>
        <div class="warper container-fluid" style="padding: 0;margin:0;min-height:250px;max-width:600px;">
			<div class="row" style="margin:auto">
            	<div class="col-md-12">
				<div class="page-header" style="margin:25px 0 25px"><h1>Aktifasi</h1></div>
                	<div class="panel panel-default">
                        <div class="panel-body" style="padding:20px 15px 0">
							<span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
							<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                        </div>
                    </div>
                 </div>
			</div>
       </div>
    </center>
	<?php
	$qtsite = "SELECT * FROM site";
	$tsite = $databaseConnection->prepare($qtsite);
	$tsite->execute();
	$site = $tsite->fetchAll();
	foreach ($site as $site) 
	?>
	<p class="text-center">Copyright 2021 <a href="/"><b><?php echo $site['name']; ?></b></a></p>

	
	<script id="jsbin-javascript">
		$("input").on("keypress",function(e){
		var val = $(this).val();
		var open = val.indexOf('<');
		var close = val.indexOf('>');
		if(open!==-1 && close!==-1) {
		$(this).val(val.replace(val.slice(open,close+1),""));
		}
		});
	</script>

    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>