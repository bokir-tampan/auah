<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />

<!-- JQuery v1.9.1 -->
<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>

<!-- Title  -->
<title>Dashboard</title>
</head>

<body>
	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
			<?php
			$qtusers = "SELECT * FROM users";
			$tusers = $databaseConnection->prepare($qtusers);
			$tusers->execute();
			$users = $tusers->fetchAll();
			foreach ($users as $users)
			?>
            <div class="page-header"><center><h3><i class="fa fa-home fa-fw"></i> Dashboard</h3></center></div>
			<div class="row">
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Jumlah Server</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-database fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$hitung = $databaseConnection->prepare("SELECT COUNT(*) FROM server");
											$hitung->execute();
											$num_rows = $hitung->fetchColumn();
											echo $num_rows;
											?> Server" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Server Member</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-server fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horde = $databaseConnection->prepare("SELECT COUNT(*) FROM server WHERE status1 = :status1");
											$status1 = 'Tersedia';
											$horde->bindParam(':status1', $status1);
											$horde->execute();
											$servnum_rows = $horde->fetchColumn();
											echo $servnum_rows;
											?> Server Tersedia" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Server Reseller</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-server fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horde = $databaseConnection->prepare("SELECT COUNT(*) FROM server WHERE status2 = :status2");
											$status2 = 'Tersedia';
											$horde->bindParam(':status2', $status2);
											$horde->execute();
											$servnum_rows = $horde->fetchColumn();
											echo $servnum_rows;
											?> Server Tersedia" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Server Trial</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-server fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horde = $databaseConnection->prepare("SELECT COUNT(*) FROM server WHERE status3 = :status3");
											$status3 = 'Tersedia';
											$horde->bindParam(':status3', $status3);
											$horde->execute();
											$servnum_rows = $horde->fetchColumn();
											echo $servnum_rows;
											?> Server Tersedia" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Jumlah Member</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
									$huser = $databaseConnection->prepare("SELECT COUNT(*) FROM member");
									$huser->execute();
									$usernum_rows = $huser->fetchColumn();
									
									echo $usernum_rows;
									?> Member
									
									
									" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Member Aktif</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
									$huser = $databaseConnection->prepare("SELECT COUNT(*) FROM member WHERE status = :status");
									$status = 'Aktif';
									$huser->bindParam(':status', $status);
									$huser->execute();
									$usernum_rows = $huser->fetchColumn();
									
									echo $usernum_rows;
									?> Member
									" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Member Pending</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
									$huser = $databaseConnection->prepare("SELECT COUNT(*) FROM member WHERE status = :status");
									$status = 'Pending';
									$huser->bindParam(':status', $status);
									$huser->execute();
									$usernum_rows = $huser->fetchColumn();
									
									echo $usernum_rows;
									?> Member
									" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Member Terkunci</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
									$huser = $databaseConnection->prepare("SELECT COUNT(*) FROM member WHERE status = :status");
									$status = 'Kunci';
									$huser->bindParam(':status', $status);
									$huser->execute();
									$usernum_rows = $huser->fetchColumn();
									
									echo $usernum_rows;
									?> Member
									" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Jumlah Pembelian</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-cart-plus fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horder = $databaseConnection->prepare("SELECT COUNT(*) FROM akun WHERE kode = :kode");
											$kode = 1;
											$horder->bindParam(':kode', $kode);
											$horder->execute();
											$ordernum_rows = $horder->fetchColumn();
											echo $ordernum_rows;
											?> Akun" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Pembelian Member</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-cart-plus fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horder = $databaseConnection->prepare("SELECT COUNT(*) FROM akun WHERE dari = :dari");
											$dari = "Member";
											$horder->bindParam(':dari', $dari);
											$horder->execute();
											$ordernum_rows = $horder->fetchColumn();
											echo $ordernum_rows;
											?> Akun" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Pembelian Reseller</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-cart-plus fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horder = $databaseConnection->prepare("SELECT COUNT(*) FROM akun WHERE dari = :dari");
											$dari = "Reseller";
											$horder->bindParam(':dari', $dari);
											$horder->execute();
											$ordernum_rows = $horder->fetchColumn();
											echo $ordernum_rows;
											?> Akun" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Config Tersedia</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-download fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horder = $databaseConnection->prepare("SELECT COUNT(*) FROM config");
											$horder->execute();
											$ordernum_rows = $horder->fetchColumn();
											echo $ordernum_rows;
											?> Config" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Jumlah Saldo</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-money fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$hitung1 = $databaseConnection->prepare("SELECT SUM(balance1) FROM member");
											$hitung1->execute();
											$num_rows1 = $hitung1->fetchColumn();
											$hitung2 = $databaseConnection->prepare("SELECT SUM(balance2) FROM member");
											$hitung2->execute();
											$num_rows2 = $hitung2->fetchColumn();
											$hitung3 = $databaseConnection->prepare("SELECT SUM(balance3) FROM member");
											$hitung3->execute();
											$num_rows3 = $hitung3->fetchColumn();
											echo number_format($num_rows1+$num_rows2, 0 , '' , '.' );
											?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Saldo Member</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-money fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php echo number_format($num_rows1, 0 , '' , '.' );?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Saldo Reseller</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-money fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php echo number_format($num_rows2, 0 , '' , '.' );?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Akses Trial</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-clock-o fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php echo $num_rows3;?> Member" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Info -->
			<div class="row">
				<?php
					$qtinformasi = "SELECT * FROM informasi";
					$tinformasi = $databaseConnection->prepare($qtinformasi);
					$tinformasi->execute();
					$informasi = $tinformasi->fetchAll();
					foreach ($informasi as $info)
						
				?>
				<div class="col-lg-6">
                	<div class="panel panel-default">
                        <div class="panel-heading"><center><i class="fa fa-bullhorn fa-fw"></i> Petunjuk Pemakaian</center></div>
                        <div class="panel-body" style="min-height:16.5pc;">
							<p>Pastikan Akses Anda dan Seluruh Member menggunakan https (SSL).</p><hr>
							<p>Usahakan Password Admin dibuat dengan sulit dan ganti secara berkala.</p><hr>
							<p>Kendala apapun yang ditemui Anda dan Member, silahkan hubungi Saya via email.</p><hr>
							<p>Semoga Hari-hari Anda menyenangkan.</p>
							<p>Keep Spirit and Happy :)</p>
                        </div>
                    </div>
                </div>
				<div class="col-lg-6">
                	<div class="panel panel-default">
                        <div class="panel-heading"><center><i class="fa fa-info fa-fw"></i> About Panel</center></div>
						<div class="panel-body" style="min-height:16.5pc;padding:0">
							<font color=#2b2f3e>
							<hr>
							<center><h1>Premium SSH Panel</h3></center>
							<center><h5>Reseller Panel</h5><hr class="dotted"></center>
							<center><h5>Contact Person:</h5></center>
							<center>
								<h5><i class="fa fa-envelope fa-fw"></i> fornesiafreak@gmail.com</h5><hr class="dotted">
							</center>
							<?php
							$qabout = "SELECT * FROM users";
							$about = $databaseConnection->prepare($qabout);
							$about->execute();
							$about = $about->fetchAll();
							foreach ($about as $about) 
							?>
							<center>
								<h5>
									<b><i>Your Panel Registed Until:<br><?php echo date('d F Y', strtotime($about['expiredate'])); ?></i></b>
								</h5>
								<hr>
							</center>
							</font>
						</div>
                    </div>
                </div>
			</div>
		</div>
		
        <?php include '../base/footer.php'; ?>
        
    
    </section>
    
	<!-- Underscore -->
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    
	<!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- Chart JS -->
    <script src="../asset/js/plugins/DevExpressChartJS/dx.chartjs.js"></script>
    <script src="../asset/js/plugins/DevExpressChartJS/world.js"></script>
   	<!-- For Demo Charts -->
    <script src="../asset/js/plugins/DevExpressChartJS/demo-charts.js"></script>
    <script src="../asset/js/plugins/DevExpressChartJS/demo-vectorMap.js"></script>
    
    <!-- Sparkline JS -->
    <script src="../asset/js/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!-- For Demo Sparkline -->
    <script src="../asset/js/plugins/sparkline/jquery.sparkline.demo.js"></script>
    
    <!-- Angular JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.0-beta.14/angular.min.js"></script>
    <!-- ToDo List Plugin -->
    <script src="../asset/js/angular/todo.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
 
</body>
</html>