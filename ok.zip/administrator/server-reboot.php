<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta content="20;url=manage-server.php" http-equiv="REFRESH" />

<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />

<!-- Title -->
<title>Reboot Server</title>
</head>

<body>



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>

        <div class="warper container-fluid">
		
			<div class="page-header"><center><h3>Reboot Server</h3></center></div>
			
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
                	<div class="panel panel-default">
						<?php
                        $qtampil = "SELECT * FROM server WHERE idserver = :idserver LIMIT 0,1";
                        $tampil = $databaseConnection->prepare($qtampil);
                        $tampil->bindParam(':idserver', $_REQUEST['idserver']);
                        $tampil->execute();
                        $server = $tampil->fetchAll();
                        foreach ($server as $serv) {
							$link_config = $serv['link_config'];
                        ?>
                        <div class="panel-heading"><center><i class="fa fa-power-off fa-fw"></i> Reboot Server <?php echo $serv['namaserver'];?></center></div>
						<div class="panel-body" style="padding:0">
							<center>
							<h4><?php
								error_reporting(0);
								$command = "reboot";

								if($ssh = ssh2_connect($serv['host'], "22" )) {
									if(ssh2_auth_password($ssh, "root", $serv['password'])) {
										$stream = ssh2_exec($ssh, $command);
										stream_set_blocking($stream, true);
										$data = '';
										while($buffer = fread($stream, 4096)) {
											$data .= $buffer;
										}
										fclose($stream);
										echo "<span class='label label-danger'>Status Server Rebooted</span>";
										}
									elseif ($data != '') {
											echo "Error";
										}
									else {
										 echo "<span class='label label-danger'>Status Server Offline</span>";
									 }
								}else {
										 echo "<span class='label label-danger'>Status Server Down!</span>";
								}
								?>
							</h4>
							</center>
						</div>
						<?php } ?>
                    </div>
				</div>
		
    </section>
    <section class="content">
		<?php include '../base/footer.php'; ?>
	</section>

    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>