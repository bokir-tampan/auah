<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
<?php if(isset($_SESSION['username'])) { ?>
<?php } else { header("location: login.php"); } ?>
<div class="page-header"><center><h3>Backup User</h3></center></div>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-body">
				<table border="1">
					<thead>
						<tr>
							<th>Server</th>
							<th>Host</th>
							<th>Username</th>
							<th>Password</th>
							<th>Creator</th>
							<th>From</th>
							<th>Expire Date</th>
						</tr>
					</thead>
					<tbody>
						<?php
						header("Content-type: application/vnd-ms-excel");
						header("Content-Disposition: attachment; filename=Backup-User-Reseller.xls");
						$qtserver = "SELECT * FROM akun WHERE dari = :dari";
						$dari = "Reseller";
						$tserver = $databaseConnection->prepare($qtserver);
						$tserver->bindParam(':dari', $dari);
						$tserver->execute();
						$server = $tserver->fetchAll();
						foreach ($server as $serv) {
						?>
						<tr class="odd gradeX">
							<td><?php echo $serv['namaserver']; ?></td>
							<td><?php echo $serv['host']; ?></td>
							<td><?php echo $serv['uservpn']; ?></td>
							<td><?php echo $serv['passvpn']; ?></td>
							<td><?php echo $serv['username']; ?></td>
							<td><?php echo $serv['dari']; ?></td>
							<td>
								<?php 
								$habis = $serv['expiredate']; 
								$tgl_habis = strtotime($habis);
								$tgl_habis1 = strtotime($habis . ' - 1 Days');
								$tgl_habis2 = strtotime($habis . ' - 2 Days');
								$tgl_habis3 = strtotime($habis . ' - 3 Days');
								$tgl_habis4 = strtotime($habis . ' - 4 Days');
								$tgl_habis5 = strtotime($habis . ' - 5 Days');
								$tgl_skrg = strtotime($tgl);

								if ($tgl_habis < $tgl_skrg) {
									echo "<font color=#FF0000>Akun Expired</font>";
									}
									elseif ($tgl_habis == $tgl_skrg) {
										echo $habis . '<font color=#ff8d00> (Expired Hari ini)</font>';
									}
									elseif ($tgl_habis1 == $tgl_skrg) {
										echo $habis . '<font color=#ff8d00> (Expired 1 Hari Lagi)</font>';
									}
									elseif ($tgl_habis2 == $tgl_skrg) {
										echo $habis . '<font color=#ff8d00> (Expired 2 Hari Lagi)</font>';
									}
									elseif ($tgl_habis3 == $tgl_skrg) {
										echo $habis . '<font color=#ff8d00> (Expired 3 Hari Lagi)</font>';
									}
									elseif ($tgl_habis4 == $tgl_skrg) {
										echo $habis . '<font color=#ff8d00> (Expired 4 Hari Lagi)</font>';
									}
									elseif ($tgl_habis5 == $tgl_skrg) {
										echo $habis . '<font color=#ff8d00> (Expired 5 Hari Lagi)</font>';
									}
									else {
									echo "<font color=#0F9D28>" . $habis . "</font>";
									}
								?>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="page-header"><center><h6>Backup Date <?php echo $tgl; ?></h6></center></div>
<div class="page-header"><center><h5>Panel Reseller SSH</h5></center></div>
</body>
</html>