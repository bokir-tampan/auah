<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['simpan'])) {
	
	$pengumuman = $_POST['pengumuman'];
	$peraturan = $_POST['peraturan'];
	$deposit = $_POST['deposit'];
	
	$qserver = "UPDATE informasi SET pengumuman = :pengumuman, peraturan = :peraturan, deposit = :deposit WHERE id = :id";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':pengumuman', $pengumuman);
	$exserver->bindParam(':peraturan', $peraturan);
	$exserver->bindParam(':deposit', $deposit);
	$exserver->bindParam(':id', $_POST['id']);
	
	if($exserver->execute()) {
		
		$qtserver = "SELECT * FROM member";
		$tserver = $databaseConnection->prepare($qtserver);
		$tserver->execute();
		$server = $tserver->fetchAll();
		foreach ($server as $serv) {
		// kirim email
		require_once('../function.php');
		$to       = $serv['email'];
		$subject  = 'Pengumuman';
		$message  = '<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tbody>
		<tr>
		<td bgcolor="#f2f2f2" style="font-size:0px">&nbsp;</td>
		<td bgcolor="#ffffff" width="660" align="center">
		<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tbody>
		<tr>
		<td align="center" width="600" valign="top">
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tbody>
		<tr>
		<td bgcolor="#f2f2f2" style="padding-top:10px"></td>
		</tr>
		<tr>
		<td bgcolor="#f2f2f2" style="padding-top:10px"></td>
		</tr>
		<tr>
		<td align="center" valign="top" bgcolor="#ffffff">
		<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:10px;padding-top:20px" width="100%">
		<tbody>
		<tr valign="bottom">    
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td>
		<span>
		<b>Pengumuman</b>
		</span>                                
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>
		</tr>
		</tbody>
		</table>
		<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:10px;padding-top:10px;margin-bottom:10px" width="100%">
		<tbody>
		<tr valign="bottom">    
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td valign="top" style="font-family:Calibri,Trebuchet,Arial,sans serif;font-size:15px;line-height:22px;color:#333333">
		<p>Yth. <a href="mailto:'.$serv['email'].'" target="_blank">'.$serv['nama'].'</a></p><br>
		<b>A. PENGUMUMAN</b>
		<p>'.$pengumuman.'</p>
		<br><br>
		<b>B. INFORMASI DEPOSIT</b>
		<p>'.$deposit.'</p>
		<br><br>
		<b>C. PERATURAN SERVER</b>
		<p>'.$peraturan.'</p>
		<p><br><br>Salam Hormat,<br>Admin</p>
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>
		</tr>
		</tbody>
		</table>
		</td>
		</tr>
		</tbody>
		</table>
		</td>
		</tr>
		</tbody>
		</table>
		<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tbody>
		<tr>
		<td align="center" width="600" valign="top">
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tbody>
		<tr>
		<td bgcolor="#f2f2f2" style="padding-top:20px"></td>
		</tr>
		<tr>
		<td align="center" valign="top" bgcolor="#f2f2f2">
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tbody>
		<tr valign="bottom">   
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td>
		<table align="left" border="0" cellpadding="0" cellspacing="0">
		<tbody>
		<tr>
		<td style="font-family:Calibri,Trebuchet,Arial,sans serif;font-size:13px;color:#666;font-weight:bold">
		<span id="m_-6118667421211539915bottomLinks">
		<div style="margin:5px 0;padding:0">
		<span style="display:inline">
		<span>
		<a href="https://www.fornesia.com" style="text-decoration:none" target="_blank">
		Bantuan&nbsp;
		</a>
		</span>
		<span style="color:#ccc"><span> | </span></span>
		<span>
		<a href="https://www.fornesia.com" style="text-decoration:none" target="_blank" >
		Webiste&nbsp;
		</a>
		</span>
		</span>
		</div>
		</span>
		</td>
		</tr>
		</tbody>
		</table>
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>    
		</tr>
		</tbody>
		</table>           
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tbody>
		<tr valign="bottom">   
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td>
		<p> Jangan balas ke email ini. Untuk menghubungi kami, klik 
		<strong><a href="" style="text-decoration:none" target="_blank" >Bantuan dan Hubungi</a></strong>.
		</p>
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>
		</tr>
		</tbody>
		</table>  
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tbody>
		<tr valign="bottom">   
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td>
		<span>  
		<table border="0" cellpadding="0" cellspacing="0" id="m_-6118667421211539915emailFooter" style="padding-top:10px;font:12px Arial,Verdana,Helvetica,sans-serif;color:#292929" width="100%">
		<tbody>
		<tr>
		<td>
		<p>Hak Cipta © 2020 fornesia.com.</p>
		</td>
		</tr>
		</tbody>
		</table>
		</span>
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>    
		</tr>
		</tbody>
		</table>    

		</td>
		</tr>
		</tbody>
		</table>
		</td>

		</tr>
		</tbody>
		</table>
		</td>
		<td bgcolor="#f2f2f2" style="font-size:0px">&nbsp;</td>
		</tr>
		</tbody>
		</table>
		';
		$from_name = 'no reply';
		$from = 'noreply@fornesia.com';
		smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
		}
		$message = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Informasi Berhasil Dirubah!</h4>
			</div>
		';
	} else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Gagal Merubah Informasi!</h4>
			</div>
		';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Berikan Informasi</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-bullhorn fa-fw"></i> Informasi</h3></center></div>
            
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($message)){ echo $message; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-bullhorn fa-fw"></i> Berikan Informasi</div>
                        <div class="panel-body">                        
                        <?php
                        $qtampil = "SELECT * FROM informasi WHERE id = :id LIMIT 0,1";
                        $id = "1";
                        $tampil = $databaseConnection->prepare($qtampil);
                        $tampil->bindParam(':id', $id);
                        $tampil->execute();
                        $server = $tampil->fetchAll();
                        foreach ($server as $serv) {
                        ?>
                        	<form  method="post" class="validator-form" action="">
								<div class="form-group">
									<label class="control-label">Pengumuman</label>
									<textarea type="text" class="form-control" name="pengumuman"><?php echo $serv['pengumuman']; ?></textarea>
									<small>
									Berikan Pengumuman Kepada Semua User.<br>
									<i>Pengumuman Akan Tampil Pada Beranda User.</i>
									</small>
								</div>
								<div class="form-group">
									<label class="control-label">Peraturan Server</label>
									<textarea type="text" class="form-control" name="peraturan"><?php echo $serv['peraturan']; ?></textarea>
									<small>
									Berikan Peraturan Server Kepada Semua User.<br>
									<i>Peraturan Server Akan Tampil Pada Beranda User.</i>
									</small>
								</div>
								<div class="form-group">
									<label class="control-label">Cara Deposit</label>
									<textarea type="text" class="form-control" name="deposit"><?php echo $serv['deposit']; ?></textarea>
									<small>
									Berikan Cara Deposit Kepada Semua User.<br>
									<i>Cara Deposit Akan Tampil Pada Menu Tambah Saldo.</i>
									</small>
								</div>
								<input type="hidden" name="id" value="<?php echo $serv['id']; ?>">
								<hr class="dotted">
								<div class="form-group">
									<button type="submit" class="btn btn-primary" name="simpan" value="Add">
										<i class="fa fa-save"></i> Simpan
									</button>
									<a href="dashboard.php">
										<button type="button" class="btn btn-info" id="resetBtn">
											<i class="fa fa-arrow-circle-left"></i> Kembali
										</button>
									</a>
								</div>
                            </form><?php } ?>            
                        </div>
                    </div>
                 </div>
            </div>
       </div>
	   <?php include '../base/footer.php'; ?>
    
    </section>    
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>