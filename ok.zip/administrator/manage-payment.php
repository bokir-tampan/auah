<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

if(isset($_POST['addfunds1'])) {
	
	$balance1 = $_POST['balance1'];
	$email = $_POST['email'];
	
	$qtampung = "SELECT balance1 FROM member WHERE email = :email";
	$tampung = $databaseConnection->prepare($qtampung);
	$tampung->bindParam(':email', $email);
	$tampung->execute();
	
	while($total = $tampung->fetch(PDO::FETCH_OBJ)){
		$a = $total->balance1;
		$b = $a + $balance1;
	}
	
	if($email == "Silahkan Pilih") {
		$pilih1 = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Penambahan Saldo Gagal!</h4>
			<p>Username Member belum Anda Pilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
			';
	} else {
	$qsimpan = "UPDATE member SET balance1 = :balance1 WHERE email = :email";
	$simpan = $databaseConnection->prepare($qsimpan);
	$simpan->bindParam(':balance1', $b);
	$simpan->bindParam(':email', $email);
	
	if($simpan->execute()) {
		// SMTP Mailer
		require_once('../function.php');
		$to       = $email;
		$subject  = "Informasi Tambah Saldo";
		// Message SMTP Mailer
		$message  = "
		<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;margin-to:15px;border-top:1px solid #eee;font-size:16px'><b>Informasi Tambah Saldo</b></div>
		<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
			<tbody>
				<tr style='background:#f2f2f2'>
					<td style='padding:8px 10px'>Email Anda</td>
						<th style='padding:8px 2px'>:</th>
						<th style='padding:8px 10px'>".$email."</th>
				<tr>
				<tr>
					<td style='padding:8px 10px;width:100px'>Penambahan Saldo Member</td>
						<th style='padding:8px 2px'>:</th>
						<th style='padding:8px 10px'>".number_format($balance1, 0 , '' , '.' )."</th>
				</tr>
			</tbody>
		</table>
		";
		$from_name = 'no reply';
		$from = 'noreply@fornesia.com';
		smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
		$message1 = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Saldo Member Berhasil Ditambah!</h4>
			<p>Email : '.$email.'</p>
			<p>Tambahan Saldo : '.number_format($balance1, 0 , '' , '.' ).'</p>
			<hr>
			<p class="mb-0">Silahkan Chek <a href="manage-member.php">Saldo</a>.</p>
			</div>
		';
			} else {
				$gagal1 = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Penambahan Saldo Gagal!</h4>
				<p>Ada Masalah pada Database / Koneksi</p>
				<hr>
				<p class="mb-0">Silahkan coba kembali.</p>
				</div>
			';
			}
		}
}

if(isset($_POST['addfunds2'])) {
	
	$balance2 = $_POST['balance2'];
	$email = $_POST['email'];
	
	$qtampung = "SELECT balance2 FROM member WHERE email = :email";
	$tampung = $databaseConnection->prepare($qtampung);
	$tampung->bindParam(':email', $email);
	$tampung->execute();
	
	while($total = $tampung->fetch(PDO::FETCH_OBJ)){
		$a = $total->balance2;
		$b = $a + $balance2;
	}
	
	if($email == "Silahkan Pilih") {
		$pilih2 = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Penambahan Saldo Gagal!</h4>
			<p>Username Member belum Anda Pilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
			';
	} else {
	$qsimpan = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
	$simpan = $databaseConnection->prepare($qsimpan);
	$simpan->bindParam(':balance2', $b);
	$simpan->bindParam(':email', $email);
	
	if($simpan->execute()) {
		// SMTP Mailer
		require_once('../function.php');
		$to       = $email;
		$subject  = "Informasi Tambah Saldo";
		// Message SMTP Mailer
		$message  = "
		<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;margin-to:15px;border-top:1px solid #eee;font-size:16px'><b>Pesan Masuk</b></div>
		<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
			<tbody>
				<tr style='background:#f2f2f2'>
					<td style='padding:8px 10px'>Email Anda</td>
						<th style='padding:8px 2px'>:</th>
						<th style='padding:8px 10px'>".$email."</th>
				<tr>
				<tr>
					<td style='padding:8px 10px;width:100px'>Penambahan Saldo Reseller</td>
						<th style='padding:8px 2px'>:</th>
						<th style='padding:8px 10px'>".number_format($balance2, 0 , '' , '.' )."</th>
				</tr>
			</tbody>
		</table>
		";
		$from_name = 'no reply';
		$from = 'noreply@fornesia.com';
		smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
		$message2 = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Saldo Reseller Berhasil Ditambah!</h4>
			<p>Email : '.$email.'</p>
			<p>Tambahan Saldo : '.number_format($balance2, 0 , '' , '.' ).'</p>
			<hr>
			<p class="mb-0">Silahkan Chek <a href="manage-member.php">Saldo</a>.</p>
			</div>
		';
			} else {
				$gagal2 = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Penambahan Saldo Gagal!</h4>
				<p>Ada Masalah pada Database / Koneksi</p>
				<hr>
				<p class="mb-0">Silahkan coba kembali.</p>
				</div>
			';
			}
		}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<?php include 'base/schema.php'; ?>

<title>Manage Payment</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="../asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>	


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
			<div class="page-header"><center><h3><i class="fa fa-money fa-fw"></i> Manage Payment</small></h3><center></div>
			<div class="row">
				<div class="col-md-12 col-sm-6">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Manage Payment</center></div>
						<div class="panel-body">
							<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
								<thead>
									<tr>
										<th>No</th>
										<th>Pengirim</th>
										<th>Email</th>
										<th>Jenis Saldo</th>
										<th>Nominal</th>
										<th>Via</th>
										<th>Bukti</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$qtserver = "SELECT * FROM payment";
									$tserver = $databaseConnection->prepare($qtserver);
									$tserver->execute();
									
									while ($serv = $tserver->fetch(PDO::FETCH_OBJ)) {
										
									?>
									<tr class="odd gradeX">
										<td><?php echo $serv->id; ?></td>
										<td><?php echo $serv->nama_pengirim; ?></td>
										<td><?php echo $serv->email; ?></td>
										<td><?php echo $serv->saldo; ?></td>
										<td><?php echo number_format($serv->total, 0 , '' , '.' ); ?></td>
										<td><?php echo $serv->via; ?></td>
										<td><a href="../screenshot/<?php echo $serv->buktitransfer; ?>" target="_blank"><?php echo $serv->buktitransfer; ?></a></td>
										<td>
											<?php if($serv->lunas == "Tidak") { ?>
											<a href="#" onclick="lunas(<?php echo $serv->id;?>)" title="Lunas" >
												<button class="btn btn-success">
													<i class="fa fa-money fa-fw"></i> Lunas
												</button>
											</a>
											<a href="#" onclick="deletepayment(<?php echo $serv->id;?>)" title="Delete" >
												<button class="btn btn-danger">
													<i class="fa fa-trash fa-fw"></i> Delete
												</button>
											</a>
											<?php } else { ?>
											<button class="btn btn-success" disabled >
												<i class="fa fa-check fa-fw"></i> Lunas
											</button>
											<?php } ?>
										</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>

						</div>
					</div>
				</div>

				<div class="col-md-6 col-sm-6">                	
                	<div class="panel panel-default">
                        <div class="panel-heading"><center>Tambah Saldo Member</center></div>
                        <div class="panel-body">
							<?php if(isset($pilih1)){ echo $pilih1; } ?>
							<?php if(isset($message1)){ echo $message1; } ?>
							<?php if(isset($gagal1)){ echo $gagal1; } ?>
                        	<form  method="post" class="validator-form form-horizontal" action="#">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">User</label>
                                    <?php
                                    $qselect = "SELECT username, email FROM member";
                                    $tselect = $databaseConnection->prepare($qselect);
                                    $tselect->execute();
                                    $data = $tselect->fetchAll();
                                    ?>
                                    <div class="col-lg-9">
                                        <select name="email" id="email" class="form-control">
											<option>Silahkan Pilih</option>
											<?php foreach ($data as $row): ?>
											<option value="<?=$row['email']?>"><?=$row['username']?> - <?=$row['email']?></option>
											<?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Rp</label>
                                    <div class="col-lg-9">
                                        <input type="number" class="form-control" name="balance1" required/>
                                    </div>
                                </div>
                            	<div class="form-group">
									<div class="col-sm-offset-3 col-sm-9">
										<button type="submit" class="btn btn-primary" name="addfunds1">
											<i class="fa fa-money fa-fw"></i> Tambah Saldo Member
										</button>
									</div>
                            	</div>
                        	</form>
						</div>
                    </div>
				</div>

				<div class="col-md-6 col-sm-6">                	
                	<div class="panel panel-default">
                        <div class="panel-heading"><center>Tambah Saldo Reseller</center></div>
                        <div class="panel-body">
							<?php if(isset($pilih2)){ echo $pilih2; } ?>
							<?php if(isset($message2)){ echo $message2; } ?>
							<?php if(isset($gagal2)){ echo $gagal2; } ?>
                        	<form  method="post" class="validator-form form-horizontal" action="#">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">User</label>
                                    <div class="col-lg-9">
                                        <select name="email" id="email" class="form-control">
											<option>Silahkan Pilih</option>
											<?php foreach ($data as $row): ?>
											<option value="<?=$row['email']?>"><?=$row['username']?> - <?=$row['email']?></option>
											<?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Rp</label>
                                    <div class="col-lg-9">
                                        <input type="number" class="form-control" name="balance2" required/>
                                    </div>
                                </div>
                            	<div class="form-group">
									<div class="col-sm-offset-3 col-sm-9">
										<button type="submit" class="btn btn-primary" name="addfunds2">
											<i class="fa fa-money fa-fw"></i> Tambah Saldo Reseller
										</button>
									</div>
                            	</div>
                        	</form>
						</div>
                    </div>
				</div>

				
		</div>
		</div>
	</section>
	
	<section class="content">
		<?php include '../base/footer.php'; ?>
	</section>
    
    <!-- start: JavaScript-->
	<script type="text/javascript">
	function lunas(id) {
		var answer = confirm('Tandai Lunas?')
		if(answer) {
			window.location = 'lunas.php?id=' +id;
			}
		}
	</script>
	<script type="text/javascript">
	function deletepayment(id) {
		var answer = confirm('Are You Sure ?')
		if(answer) {
			window.location = 'deletepayment.php?id=' +id;
			}
		}
	</script>
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="../asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="../asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="../asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
   
</body>
</html>