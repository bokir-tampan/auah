<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

if(isset($_POST['tambah'])) {
	
	$username = $_POST['namauser'];
	$email = $_POST['email'];
	$pesan = $_POST['pesan'];
	
	$qserver = "UPDATE member SET pesan = :pesan WHERE iduser = :iduser";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':pesan', $pesan);
	$exserver->bindParam(':iduser', $_POST['iduser']);
	
	if($exserver->execute()) {
	// SMTP Mailer
	require_once('../function.php');
	$to       = $email;
	$subject  = "Informasi Pesan Masuk";
	// Message SMTP Mailer
	$message  = "
	<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;margin-to:15px;border-top:1px solid #eee;font-size:16px'><b>Pesan Masuk </b></div>
	<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
		<tbody>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px'>Nama Pengirim</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>Admin Panel</th>
			<tr>
			<tr>
				<td style='padding:8px 10px;width:100px'>Isi Pesan</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$pesan."</th>
			</tr>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px'>Tanggal Masuk</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$tgl."</th>
			<tr>
			<tr>
				<td style='padding:8px 10px'>Catatan</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>Jangan balas pesan ini.</th>
			</tr>
		</tbody>
	</table>
	";
	$from_name = 'no reply';
	$from = 'noreply@fornesia.com';
	smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
		
		$berhasil = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Pesan Terkirim!</p>
			</div>
		';
	} else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Pesan Tidak Terkirim!</p>
			</div>
		';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Send Message</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />

<!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>

</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-send fa-fw"></i> Send Message</h3><center></div>
            
			<div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-send fa-fw"></i> Send Message</div>
                        <div class="panel-body">
							<?php
							$qtampil = "SELECT * FROM member WHERE iduser = :iduser LIMIT 0,1";
							$tampil = $databaseConnection->prepare($qtampil);
							$tampil->bindParam(':iduser', $_REQUEST['iduser']);
							$tampil->execute();
							$server = $tampil->fetchAll();
							foreach ($server as $serv) {
							?>
                        	<form  method="post" class="validator-form" action="">                            
								<div class="form-group">
									<label class="control-label">Username</label>
									<input type="text" class="form-control" name="namauser" value="<?php echo $serv['username']; ?>" readonly />
								</div>
								<div class="form-group">
									<label class="control-label">Email</label>
									<input type="text" class="form-control" name="email" value="<?php echo $serv['email']; ?>" readonly />
								</div>
								<textarea name="pesan" rows="6" style="width: 100%;"><?php echo $serv['pesan']; ?></textarea>
								<small>Pesan ini Akan Tampil di Menu Pesan Member / Kosongkan Pesan Untuk Menghapus Notifikasi Pesan di Panel User.</small>

								<input type="hidden" name="iduser" value="<?php echo $serv['iduser']; ?>">
								  
								<hr class="dotted">
								
								<div class="form-group">
									<button type="submit" class="btn btn-primary" name="tambah" value="Add">
										<i class="fa fa-send fa-fw"></i> Kirim
									</button>
									<a class="btn btn-danger" href="#" onclick="deletepesan(<?php echo $serv['iduser'];?>)"  title="Hapus Member">
										<i class="fa fa-trash-o fa-fw"></i> Hapus
									</a>
									<a href="manage-member.php">
										<button type="button" class="btn btn-info" id="resetBtn">
											<i class="fa fa-arrow-circle-left fa-fw"></i> Kembali
										</button>
									</a>
								</div>
                            </form>
							<?php } ?>            
                        </div>
                    </div>
                 </div>
            </div>
		</div>
        
		<?php include '../base/footer.php'; ?>
    
    </section>
    
	<!-- start: JavaScript-->
	<script type="text/javascript">
	function deletepesan(iduser) {
		var answer = confirm('Anda Yakin ?')
		if(answer) {
			window.location = 'deletepesan.php?iduser=' +iduser;
			}
		}
	</script>
	
	<script id="jsbin-javascript">
	$("textarea").on("keypress",function(e){
	var val = $(this).val();
	var open = val.indexOf('<');
	var close = val.indexOf('>');
	if(open!==-1 && close!==-1) {
	$(this).val(val.replace(val.slice(open,close+1),""));
	}
	});
	</script>
	
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>