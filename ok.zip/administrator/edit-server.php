<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['edit'])) {
	
	$namaserver = $_POST['namaserver'];
	$host = $_POST['host'];
	$password = $_POST['password'];
	$lokasi = $_POST['lokasi'];
	$isp = $_POST['isp'];
	$harga1 = $_POST['harga1'];
	$harga2 = $_POST['harga2'];
	$harga3 = $_POST['harga3'];
	$openssh = $_POST['openssh'];
	$dropbear = $_POST['dropbear'];
	$squid = $_POST['squid'];
	$ovpn = $_POST['ovpn'];
	$link_config = $_POST['link_config'];
	$status1 = $_POST['status1'];
	$status2 = $_POST['status2'];
	$status3 = $_POST['status3'];
	$catatan = $_POST['catatan'];
	
	$qserver = "UPDATE server SET namaserver = :namaserver, host = :host, password = :password, lokasi = :lokasi, isp = :isp, harga1 = :harga1, harga2 = :harga2, harga3 = :harga3, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, status1 = :status1, status2 = :status2, status3 = :status3, catatan = :catatan WHERE idserver = :idserver";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':namaserver', $namaserver);
	$exserver->bindParam(':host', $host);
	$exserver->bindParam(':password', $password);
	$exserver->bindParam(':lokasi', $lokasi);
	$exserver->bindParam(':isp', $isp);
	$exserver->bindParam(':harga1', $harga1);
	$exserver->bindParam(':harga2', $harga2);
	$exserver->bindParam(':harga3', $harga3);
	$exserver->bindParam(':openssh', $openssh);
	$exserver->bindParam(':dropbear', $dropbear);
	$exserver->bindParam(':squid', $squid);
	$exserver->bindParam(':ovpn', $ovpn);
	$exserver->bindParam(':link_config', $link_config);
	$exserver->bindParam(':catatan', $catatan);
	$exserver->bindParam(':status1', $status1);
	$exserver->bindParam(':status2', $status2);
	$exserver->bindParam(':status3', $status3);
	$exserver->bindParam(':idserver', $_POST['idserver']);
	
	if ($status1 == "Silahkan Pilih") {
			$pilih1 = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
			<p>Status Tersedia untuk Member Belum Dipilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
		';
	}
	
	elseif ($status2 == "Silahkan Pilih") {
			$pilih2 = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
			<p>Status Tersedia untuk Reseller Belum Dipilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
		';
	}
	
	elseif ($status3 == "Silahkan Pilih") {
			$pilih3 = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
			<p>Status Tersedia untuk Trial Belum Dipilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
		';
	}
	
	elseif($exserver->execute()) {
		$berhasil = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Server Berhasil Diedit!</p>
			</div>
		';
	} else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Gagal Mengedit Server!</p>
			</div>
		';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Edit Data Server</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-database fa-fw"></i> Edit Data Server</h3><center></div>
            
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($pilih1)){ echo $pilih1; } ?>
					<?php if(isset($pilih2)){ echo $pilih2; } ?>
					<?php if(isset($pilih3)){ echo $pilih3; } ?>
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-pencil-square-o fa-fw"></i> Edit Data Server</div>
                        <div class="panel-body">                        
                        <?php
                        $qtampil = "SELECT * FROM server WHERE idserver = :idserver LIMIT 0,1";
                        $tampil = $databaseConnection->prepare($qtampil);
                        $tampil->bindParam(':idserver', $_REQUEST['idserver']);
                        $tampil->execute();
                        $server = $tampil->fetchAll();
                        foreach ($server as $serv) {
                        ?>
                        	<form  method="post" class="validator-form" action="">
								<div class="row">
									<input type="hidden" class="form-control" name="idserver" value="<?php echo $serv['idserver']; ?>"/>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Name Server</label>
											<input type="text" class="form-control" name="namaserver" value="<?php echo $serv['namaserver']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Host</label>
											<input type="text" class="form-control" name="host" value="<?php echo $serv['host']; ?>"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Password</label>
											<input type="password" class="form-control" name="password" placeholder="******"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Re Password</label>
											<input type="password" class="form-control" name="confirmPassword" placeholder="******"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Lokasi</label>
											<input type="text" class="form-control" name="lokasi" value="<?php echo $serv['lokasi']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">ISP</label>
											<input type="text" class="form-control" name="isp" value="<?php echo $serv['isp']; ?>"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Harga untuk Member</label>
											<input type="number" class="form-control" name="harga1" value="<?php echo $serv['harga1']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Harga untuk Reseller</label>
											<input type="number" class="form-control" name="harga2" value="<?php echo $serv['harga2']; ?>"/>
										</div>
									</div>
								</div>
								<input type="hidden" class="form-control" name="harga3" value="1" readonly />
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Port OpenSSH</label>
											<input type="text" class="form-control" name="openssh" value="<?php echo $serv['openssh']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Port Dropbear</label>
											<input type="text" class="form-control" name="dropbear" value="<?php echo $serv['dropbear']; ?>"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Port Squid</label>
											<input type="text" class="form-control" name="squid" value="<?php echo $serv['squid']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Port VPN</label>
											<input type="text" class="form-control" name="ovpn" value="<?php echo $serv['ovpn']; ?>"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Link Config</label>
											<input type="text" class="form-control" name="link_config" value="<?php echo $serv['link_config']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Tersedia Untuk Member</label>
											<select type="text" class="form-control" name="status1" style="width:100%">
												<option>Silahkan Pilih</option>
												<option>Tersedia</option>
												<option>Tidak</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Tersedia untuk Reseller</label>
											<select type="text" class="form-control" name="status2" style="width:100%">
												<option>Silahkan Pilih</option>
												<option>Tersedia</option>
												<option>Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Tersedia untuk Trial</label>
											<select type="text" class="form-control" name="status3" style="width:100%">
												<option>Silahkan Pilih</option>
												<option>Tersedia</option>
												<option>Tidak</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Username SSH/VPN Trial</label>
											<input type="text" class="form-control" name="trial" value="<?php echo $serv['trial']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Catatan</label>
											<textarea type="text" class="form-control" name="catatan"><?php echo $serv['catatan'];?></textarea>
										</div>
									</div>
								</div>
								<hr class="dotted">
								<div class="form-group">
									<button type="submit" class="btn btn-primary" name="edit" value="Add">
										<i class="fa fa-save fa-fw"></i> Simpan
									</button>
									<a href="manage-server.php">
										<button type="button" class="btn btn-info" id="resetBtn">
											<i class="fa fa-arrow-circle-left fa-fw"></i> Kembali
										</button>
									</a>
								</div>
                            </form>
							<?php } ?>
                        </div>
                    </div>
                 </div>
            </div>
       </div>
	   <?php include '../base/footer.php'; ?>
    
    </section>    
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>