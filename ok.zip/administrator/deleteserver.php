<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');


$qdelete = "DELETE FROM server WHERE idserver = :idserver";
$delete = $databaseConnection->prepare($qdelete);
$delete->bindParam(':idserver', $_GET['idserver']);

if($result = $delete->execute()) {
	echo "<script language = 'javascript'>
	alert('Sukses Menghapus Server!');
	window.location = 'manage-server.php?action=done';
	</script>
	";
} else {
	echo "<script language = 'javascript'>
	alert('Failed to Delete Server');
	window.location = manage-server.php';
	</script> ";
}
?>
