<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

	$qsimpan = "UPDATE payment SET lunas = :lunas WHERE id = :id";
	$lunas = "Ya";
	$simpan = $databaseConnection->prepare($qsimpan);
	$simpan->bindParam(':lunas', $lunas);
	$simpan->bindParam(':id', $_GET['id']);
	
	if($simpan->execute()) {
		echo "<script language = 'javascript'>
		alert('Payment Berhasil ditandai Lunas!');
		window.location = 'manage-payment.php?action=done';
		</script>
		";
	} else {
		echo "<script language = 'javascript'>
        alert('Failed!');
        window.location = manage-payment.php';
        </script>
        ";
	}
?>