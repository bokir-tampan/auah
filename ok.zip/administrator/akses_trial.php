<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['tambah'])) {
	
	$username = $_POST['namauser'];
	$balance3 = $_POST['balance3'];
	
	$qserver = "UPDATE member SET username = :username, balance3 = :balance3 WHERE iduser = :iduser";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':username', $username);
	$exserver->bindParam(':balance3', $balance3);
	$exserver->bindParam(':iduser', $_POST['iduser']);
	
	if($balance3 == "Silahkan Pilih") {
		$pilih = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Manage Akses Pembuatan Akun Trial Gagal!</h4>
			<p>Akses Trial belum Anda Pilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
			';
	} elseif($exserver->execute()) {
		$message = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Manage Akses Pembuatan Akun Trial Berhasil!</h4>
			</div>
		';
	} else {
		$gagal = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Manage Akses Pembuatan Akun Trial Gagal!</h4>
				<p>Ada Masalah pada Database / Koneksi</p>
				<hr>
				<p class="mb-0">Silahkan coba kembali.</p>
				</div>
			';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Edit Akses Trial - Quick SSH</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-clock-o fa-fw"></i> Edit Akses Trial</h3></center></div>

            <div class="row">
            
            	<div class="col-md-offset-3 col-md-6">
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-clock-o fa-fw"></i> Edit Akses Trial</div>
                        <div class="panel-body">
							<?php if(isset($pilih)){ echo $pilih; } ?>
							<?php if(isset($message)){ echo $message; } ?>
							<?php if(isset($gagal)){ echo $gagal; } ?>
							<?php
							$qtampil = "SELECT * FROM member WHERE iduser = :iduser LIMIT 0,1";
							$tampil = $databaseConnection->prepare($qtampil);
							$tampil->bindParam(':iduser', $_REQUEST['iduser']);
							$tampil->execute();
							$server = $tampil->fetchAll();
							foreach ($server as $serv) {
							?>
                        	<form  method="post" class="validator-form" action="">
                            <div class="form-group">
                                <label class="control-label">Username</label>
                                <input type="text" class="form-control" name="namauser" value="<?php echo $serv['username']; ?>" readonly />
                            </div>
							<div class="form-group">
                                <label class="control-label">Akses Pembuatan Akun Trial</label>
								<select type="text" class="form-control" name="balance3" style="width:100%">
									<option>Silahkan Pilih</option>
									<option value="0">Tidak</option>
									<option value="1">Ya</option>
								</select>
                            </div>
                            <input type="hidden" name="iduser" value="<?php echo $serv['iduser']; ?>">
                            <hr class="dotted">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary" name="tambah" value="Add">
								<i class="fa fa-save"></i> Simpan
								</button>
                                <a href="manage-member.php">
									<button type="button" class="btn btn-info" id="resetBtn">
										<i class="fa fa-arrow-circle-left"></i> Kembali
									</button>
								</a>
                            </div>
                            </form>
                              <?php } ?>    
                        </div>
                    </div>
                 </div>
            </div>
       </div>
	   
	   <?php include '../base/footer.php'; ?>
    
    </section>

    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>