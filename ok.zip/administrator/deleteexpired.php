<?php
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

$qhapus = "DELETE FROM akun WHERE expiredate < :expired";
$hapus = $databaseConnection->prepare($qhapus);
$hapus->bindParam(':expired', $tgl);
$hapus->execute();
?>