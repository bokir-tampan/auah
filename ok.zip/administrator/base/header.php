<header class="top-head container-fluid">
   <?php
	$qtsite = "SELECT * FROM site";
	$tsite = $databaseConnection->prepare($qtsite);
	$tsite->execute();
	$site = $tsite->fetchAll();
	foreach ($site as $site) 
	?>
	<button type="button" class="navbar-toggle pull-left">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
	<nav class=" navbar-default hidden-xs" role="navigation">
		<ul class="nav navbar-nav">
			<?php
				if($site['url'] == '') {
				 echo '<li><a href="index.php"><b><i class="fa fa-globe fa-fw"></i> ' . $site['name'] . '</b></a></li>';
				} else {
				echo '<li><a href="'.$site['url'].'" target="_blank"><b><i class="fa fa-globe fa-fw"></i> ' . $site['name'] . '</b></a></li>';
				}
			?>
			<?php
				if($site['fb'] == '') {
				 echo '';
				} else {
				echo '<li><a href="' . $site['fb'] . '" target="_blank">
				<b>
				<i class="fa fa-facebook fa-fw"></i> Facebook
				</b></a></li>';
				}
			?>
			<?php
				if($site['wa'] == '') {
				 echo '';
				} else {
				echo '<li><a href="http://api.whatsapp.com/send?phone=' . $site['wa'] . '" target="_blank">
				<b>
				<i class="fa fa-whatsapp fa-fw"></i> Whatsapp
				</b></a></li>';
				}
			?>
		</ul>
	</nav>
	<ul class="nav-toolbar">
		<li class="dropdown">
		<a href="#" data-toggle="dropdown">
			<i class="fa fa-envelope-o"></i>
			<?php
				$huser = $databaseConnection->prepare("SELECT COUNT(*) FROM saran");
				$huser->execute();
				$usernum_rows = $huser->fetchColumn();
				if($usernum_rows == 0) {
				echo '';
				}
				else {
				echo '<span class="badge bg-info"> </span>';
				}
			?>
		</a>
			<div class="dropdown-menu md arrow pull-right panel panel-default arrow-top-right messages-dropdown">
				<div class="panel-heading">Pesan Masuk</div>				
				<?php
					$qtserver = "SELECT * FROM saran";
					$tserver = $databaseConnection->prepare($qtserver);
					$tserver->execute();
					while ($pesan = $tserver->fetch(PDO::FETCH_OBJ)) {
				?>
				<?php echo '<div class="list-group">
					<a href="inbox.php" class="list-group-item">
						<div class="media">
							<div class="media-body">
								<font color=red>' . ucwords(strtolower($pesan->nama_pengirim)) . '</font> Mengirim Pesan
							</div>
						</div>
					</a>
				</div>'; ?>
				<?php } ?>
			</div>
		</li>
		<li class="dropdown">
			<a href="#" data-toggle="dropdown">
				<i class="fa fa-money"></i>
				<?php
					$huser = $databaseConnection->prepare("SELECT COUNT(*) FROM payment WHERE lunas = :lunas");
					$lunas = "Tidak";
					$huser->bindParam(':lunas', $lunas);
					$huser->execute();
					$usernum_rows = $huser->fetchColumn();
				?>
				<?php
				if($usernum_rows == 0) {
				 echo '';
				} else {
					echo '<span class="badge bg-warning"> </span>';
					}
				?>
			</a>
			<div class="dropdown-menu arrow pull-right md panel panel-default arrow-top-right notifications">
				<div class="panel-heading">
					Permintaan Deposit
				</div>
					<?php
						$qtserver = "SELECT * FROM payment WHERE lunas = :lunas";
						$lunas = "Tidak";
						$tserver = $databaseConnection->prepare($qtserver);
						$tserver->bindParam(':lunas', $lunas);
						$tserver->execute();
						while ($serv = $tserver->fetch(PDO::FETCH_OBJ)) {
					?>
					<?php echo '<div class="list-group">
					<a href="manage-payment.php" class="list-group-item">
						<div class="media">
							<div class="media-body">
								<small>Saldo '.$serv->saldo.' '.number_format($serv->total, 0 , '' , '.' ) . '<font color=#087306> ' . $serv->email . '</font></small>
							</div>
						</div>
					</a>
					</div>'; ?>
					<?php } ?>
			</div>
		</li>
		<li class="dropdown"><a href="#" data-toggle="dropdown"><i class="fa fa-ellipsis-v"></i></a>
			<div class="dropdown-menu lg pull-right arrow panel panel-default arrow-top-right">
				<div class="panel-heading">
					Menu
				</div>
				<div class="panel-body text-center">
					<div class="row">
						<div class="col-xs-6 col-sm-6">
							<a href="dashboard.php" class="text-green">
								<span class="h2"><i class="fa fa-home"></i></span>
								<p class="text-gray no-margn">Dashboard</p>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6">
							<a href="manage-member.php" class="text-blue">
								<span class="h2"><i class="fa fa-user"></i></span>
								<p class="text-gray no-margn">Manage Member</p>
							</a>
						</div>
						<div class="col-xs-12 visible-xs-block"><hr></div> <!-- Only Mobile -->
						<div class="col-lg-12 col-md-12 col-sm-12 hidden-xs"><hr></div> <!-- Only Desktop -->
						<div class="col-xs-6 col-sm-6">
							<a href="manage-server.php" class="text-red">
								<span class="h2"><i class="fa fa-database"></i></span>
								<p class="text-gray no-margn">Manage Server</p>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6">
							<a href="manage-user.php" class="text-yellow">
								<span class="h2"><i class="fa fa-terminal"></i></span>
								<p class="text-gray no-margn">Manage User SSH</p>
							</a>
						</div>
						<div class="col-xs-12 visible-xs-block"><hr></div> <!-- Only Mobile -->
						<div class="col-lg-12 col-md-12 col-sm-12 hidden-xs"><hr></div> <!-- Only Desktop -->
						<div class="col-xs-6 col-sm-6">
							<a href="manage-payment.php" class="text-green">
								<span class="h2"><i class="fa fa-money"></i></span>
								<p class="text-gray no-margn">Manage Payment</p>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6">
							<a href="manage-config.php" class="text-blue">
								<span class="h2"><i class="fa fa-download"></i></span>
								<p class="text-gray no-margn">Manage Config</p>
							</a>
						</div>
						<div class="col-xs-12 visible-xs-block"><hr></div> <!-- Only Mobile -->
						<div class="col-lg-12 col-md-12 col-sm-12 hidden-xs"><hr></div> <!-- Only Desktop -->
						<div class="col-xs-6 col-sm-6">
							<a href="history.php" class="text-red">
								<span class="h2"><i class="fa fa-history"></i></span>
								<p class="text-gray no-margn">History</p>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6" style="padding-bottom:10px">
							<a href="logout.php" class="text-yellow">
								<span class="h2"><i class="fa fa-sign-out"></i></span>
								<p class="text-gray no-margn">Log Out</p>
							</a>
						</div>
					</div>
				</div>
			</div>
		</li>
	</ul>
</header>