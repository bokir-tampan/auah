<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

    $tampil = "SELECT * FROM payment WHERE id = :id";
    $stampil = $databaseConnection->prepare($tampil);
    $stampil->bindParam(':id', $_GET['id']);
    $stampil->execute();
    $server = $stampil->fetchAll();
    foreach ($server as $serv) {
		
	$pathfile = "../screenshot/" . $serv['buktitransfer'];
	unlink($pathfile);

	$hapus = "DELETE FROM payment WHERE id = :id";
	$rhapus = $databaseConnection->prepare($hapus);
	$rhapus->bindParam(':id', $_GET['id']);
	
	if($result = $rhapus->execute()){
		echo "<script language = 'javascript'>
		alert('Sukses Delete Payment!');
		window.location = 'manage-payment.php?action=done';
		</script>
		";
	} else {
		echo "<script language = 'javascript'>
        alert('Failed!');
        window.location = manage-payment.php';
        </script>
        ";
	}
}
?>