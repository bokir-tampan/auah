<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<title>History</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="../asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>	


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
            <div class="page-header"><center><h3><i class="fa fa-history fa-fw"></i> History</h3></center></div>
			<div class="row">
				<div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading"><i class="fa fa-history fa-fw"></i> Transaction History</div>
						<div class="panel-body" style="height:25pc;overflow-y:auto;text-align: justify">
							<table class="table table-responsive">
							<?php
							$qtserver = "SELECT * FROM akunlog WHERE kode = :kode";
							$kode = "1";
							$tserver = $databaseConnection->prepare($qtserver);
							$tserver->bindParam(':kode', $kode);
							$tserver->execute();
							$server = $tserver->fetchAll();
							foreach ($server as $serv) {								
							?><tbody style="border-top:3px solid #2b2f3e;border-bottom:3px solid #2b2f3e">
							<tr>
								<td>Date</td>
								<td><?php echo date('d-m-y', strtotime($serv['waktu'])); ?></td>
							</tr>
							<tr>
								<td>Time</td>
								<td><?php echo date('H:i:s', strtotime($serv['waktu'])); ?></td>
							</tr>
							<tr>
								<td>Username</td>
								<td><?php echo $serv['uservpn'];?></td>
							</tr>
							<tr>
								<td>Server</td>
								<td><?php echo $serv['namaserver']; ?></td>
							</tr>
							<tr>
								<td>Expired</td>
								<td><?php echo date('d-m-y', strtotime($serv['expiredate'])); ?></td>
							</tr>
							<tr>
								<td>Creator</td>
								<td><?php echo $serv['username']; ?></td>
							</tr>
							</tbody>
							<?php } ?>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading"><i class="fa fa-history fa-fw"></i> Registration History</div>
						<div class="panel-body" style="height:25pc;overflow-y:auto;text-align: justify">
							<table class="table table-responsive">
							<?php
							$qmember = "SELECT * FROM member";
							$member = $databaseConnection->prepare($qmember);
							$member->execute();
							$member = $member->fetchAll();
							foreach ($member as $mem) {								
							?><tbody style="border-top:3px solid #2b2f3e;border-bottom:3px solid #2b2f3e">
							<tr>
								<td>Date</td>
								<td><?php echo date('d-m-y', strtotime($mem['waktu'])); ?></td>
							</tr>
							<tr>
								<td>Time</td>
								<td><?php echo date('H:i:s', strtotime($mem['waktu'])); ?></td>
							</tr>
							<tr>
								<td>Nama</td>
								<td><?php echo $mem['nama']; ?></td>
							</tr>
							<tr>
								<td>Username</td>
								<td><?php echo $mem['username']; ?></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><?php echo $mem['email']; ?></td>
							</tr>
							<tr>
								<td>No HP</td>
								<td><?php echo $mem['nohp']; ?></td>
							</tr>
							</tbody>
							<?php } ?>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading"><i class="fa fa-clock-o fa-fw"></i> Login History</div>
						<div class="panel-body" style="height:25pc;overflow-y:auto;text-align: justify">
							<table class="table table-responsive">
							<?php
							$qmemberlog = "SELECT * FROM memberlog";
							$memberlog = $databaseConnection->prepare($qmemberlog);
							$memberlog->execute();
							$memberlog = $memberlog->fetchAll();
							foreach ($memberlog as $memlog) {								
							?><tbody style="border-top:3px solid #2b2f3e;border-bottom:3px solid #2b2f3e">
							<tr>
								<td>Date</td>
								<td><?php echo date('d-m-y', strtotime($memlog['waktulogin'])); ?></td>
							</tr>
							<tr>
								<td>Time</td>
								<td><?php echo date('H:i:s', strtotime($memlog['waktulogin'])); ?></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><?php echo $memlog['email']; ?></td>
							</tr>
							<tr>
								<td>IP</td>
								<td><?php echo $memlog['ip']; ?></td>
							</tr>
							<tr>
								<td>Validasi</td>
								<td><?php echo $memlog['valid']; ?></td>
							</tr>
							</tbody>
							<?php } ?>
							</table>
						</div>
					</div>
				</div>

			</div>
		</div>
        
      <?php include '../base/footer.php'; ?>
    
    </section>
    
    <!-- start: JavaScript-->
	<script type="text/javascript">
	function deleteuser(id) {
		var answer = confirm('Anda yakin?')
		if(answer) {
			window.location = 'deleteuser.php?id=' +id;
			}
		}
	</script>
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="../asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="../asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="../asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
   
</body>
</html>