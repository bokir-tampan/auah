<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<title>Manage Member</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="../asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />

<!-- JQuery v1.9.1 -->
<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>

</head>

<body>	


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
		
        <div class="warper container-fluid">
            <div class="page-header"><center><h3><i class="fa fa-user fa-fw"></i> Manage Member</h3></center></div>
			<div class="row">
				<div class="col-md-offset-3 col-md-3">
					<a href="tambah-member.php">
						<button class="btn btn-success" style="width: 100%"><i class="fa fa-user-plus fa-fw"></i> Tambah Member</button>
					</a>
					<hr>
				</div>
				<div class="col-md-3">
					<a href="backup-member.php">
						<button class="btn btn-info" style="width: 100%"><i class="fa fa-cloud-download fa-fw"></i> Backup Member</button>
					</a>
					<hr>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading"><i class="fa fa-user fa-fw"></i> Manage Member</div>
						
						<div class="panel-body">
							<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
								<thead>
									<tr>
										<th><small>No</small></th>
										<th><small>Username</small></th>
										<th><small>Email</small></th>
										<th><small>Member</small></th>
										<th><small>Reseller</small></th>
										<th><small>Trial</small></th>
										<th><small>Status</small></th>
										<th><small>Manage</small></th>
									</tr>
								</thead>
								<tbody>
									<?php
									$qtserver = "SELECT * FROM member";
									$tserver = $databaseConnection->prepare($qtserver);
									$tserver->execute();
									$server = $tserver->fetchAll();
									foreach ($server as $serv) {
										$status = $serv['status'];
										$balance_trial = $serv['balance3'];
									?>
									<tr class="odd gradeX">
										<td><small><?php echo $serv['iduser']; ?></small></td>
										<td><small><?php echo $serv['username']; ?></small></td>
										<td><small><?php echo $serv['email']; ?></small></td>
										<td><small><?php echo number_format($serv['balance1'], 0 , '' , '.' ); ?></small></td>
										<td><small><?php echo number_format($serv['balance2'], 0 , '' , '.' ); ?></small></td>
										<td><small><?php 
										if($serv['balance3'] == 1) {
											echo "<font color=#0F9D28>Yes</font>";
										} else {
											echo "<font color=red>No</font>";
										}
											?></small>
										</td>
										<td><small><?php
											if($status == "Pending") {
											 echo "<font color=orange>Pending</font>";
											} elseif($status == "Kunci") {
											echo "<font color=red>Locked</font>";
											} else {
											echo "<font color=#0F9D28>Aktif</font>";
											}
											?></small>
										</td>
										<td class="center">
											<a href="detail-member.php?iduser=<?php echo $serv['iduser']; ?>" title="Detail Member">
												<button type="button" class="btn btn-success">
													<small><i class="fa fa-user fa-fw"></i></small>
												</button>
											</a>
											<a href="manage-user-member.php?username=<?php echo $serv['email']; ?>" title="Chek User">
												<button type="button" class="btn btn-primary">
													<small><i class="fa fa-search fa-fw"></i></small>
												</button>
											</a>
											<a href="pesan.php?iduser=<?php echo $serv['iduser']; ?>" title="Kirim Pesan">
											<?php if($serv['pesan'] == '') {
											echo '
												<button type="button" class="btn btn-info">
													<small><i class="fa fa-envelope-o fa-fw"></i></small>
												</button>';
											}
											else {
											echo '
												<button type="button" class="btn btn-danger">
													<small><i class="fa fa-envelope-o fa-fw"></i></small>
												</button>';
											} ?>
											</a>
											<a href="edit-payment.php?iduser=<?php echo $serv['iduser']; ?>" title="Edit Payment">
												<button type="button" class="btn btn-warning">
													<small><i class="fa fa-money fa-fw"></i></small>
												</button>
											</a>
											<a href="edit-status-member.php?iduser=<?php echo $serv['iduser']; ?>" title="Edit Status">
												<button type="button" class="btn btn-primary">
													<small><i class="fa fa-bullseye fa-fw"></i></small>
												</button>
											</a>
											<a href="akses_trial.php?iduser=<?php echo $serv['iduser']; ?>" title="Edit Akses Trial">
												<button type="button" class="btn btn-info">
													<small><i class="fa fa-clock-o fa-fw"></i></small>
												</button>
											</a>
											<a href="edit-pass-member.php?iduser=<?php echo $serv['iduser']; ?>" title="Edit Password Member">
												<button type="button" class="btn btn-warning">
													<small><i class="fa fa-key fa-fw"></i></small>
												</button>
											</a>
											<a class="btn btn-danger" href="#" onclick="deletemember(<?php echo $serv['iduser'];?>)"  title="Hapus Member">
												<small><i class="fa fa-trash fa-fw"></i></small>
											</a>
										</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>

						</div>
					</div>
				</div>
			</div>
        </div>
        
      <?php include '../base/footer.php'; ?>
    
    </section>
    <!-- Content Block Ends Here (right box)-->
    
    <!-- start: JavaScript-->
	<script type="text/javascript">
	function deletemember(iduser) {
		var answer = confirm('Anda Yakin ?')
		if(answer) {
			window.location = 'deletemember.php?iduser=' +iduser;
			}
		}
	</script>
    
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="../asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="../asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="../asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
   
</body>
</html>