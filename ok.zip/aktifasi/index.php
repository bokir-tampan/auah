<?php
ob_start();
session_start();
include '../asset/css/config.php';
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
	
	
	$id = $_GET['id'];
	
	if($id != "") {
	// Ambil Kode Validasi
	$qcek = "SELECT * FROM member WHERE validasi = :id";
	$cek = $databaseConnection->prepare($qcek);
	$cek->bindParam(':id', $id);
	$cek->execute();
	
	// Ambil Keterangan Member
	while ($aktifasi = $cek->fetch(PDO::FETCH_OBJ)) {
	$email = $aktifasi->email;
	$nama = $aktifasi->nama;
	$username = $aktifasi->username;
	$jk = $aktifasi->jk;
	$kota = $aktifasi->kota;
	$prov = $aktifasi->prov;
	$balance1 = $aktifasi->balance1;
	$balance2 = $aktifasi->balance2;
	$nohp = $aktifasi->nohp;
	$waktu = $aktifasi->waktu;
	$status = $aktifasi->status;
	}
	
	// Logika jika status aktif dan terkunci
	if($status == "Aktif") {
	$errormsg = '
	<div class="alert alert-danger" role="alert">
	<center><b>Akun Sudah Terverifikasi.</b></center>
	</div>';
	}
	// Logika jika status aktif dan terkunci
	elseif($status == "Kunci") {
	$errormsg = '
	<div class="alert alert-danger" role="alert">
	<center><b>Akun Sudah Terverifikasi.</b></center>
	</div>';
	}
	
	// Logika jika status (member) tidak ada
	elseif($status == "") {
	$errormsg = '
	<div class="alert alert-danger" role="alert">
	<center><b>Link Aktifasi Salah.</b></center>
	</div>';
	}
	// Logika jika status member pending (OK)
	else {
	$qserver = "UPDATE member SET status = :statusbaru, validasi = :validasibaru WHERE email = :email";
	$statusbaru = "Aktif";
	$validasibaru = "Teraktifasi";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':statusbaru', $statusbaru);
	$exserver->bindParam(':validasibaru', $validasibaru);
	$exserver->bindParam(':email', $email);
	$exserver->execute();
	// SMTP Mailer
	require_once('../function.php');
	$to       = $email;
	$subject  = "Informasi Status Aktif";
	// Message SMTP Mailer
	$message  = '
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody>
				<tr>
				<td bgcolor="#f2f2f2" style="font-size:0px">&nbsp;</td>
				<td bgcolor="#ffffff" width="660" align="center">
				<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody>
				<tr>
				<td align="center" width="600" valign="top">
				<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<tbody>
				<tr>
				<td bgcolor="#f2f2f2" style="padding-top:10px"></td>
				</tr>
				<tr>
				<td bgcolor="#f2f2f2" style="padding-top:10px"></td>
				</tr>
				<tr>
				<td align="center" valign="top" bgcolor="#ffffff">
				<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:10px;padding-top:20px" width="100%">
				<tbody>
				<tr valign="bottom">    
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td>
				<span>
				<b>INFORMASI STATUS AKTIF</b>
				</span>                                
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>
				</tr>
				</tbody>
				</table>
				<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:10px;padding-top:10px;margin-bottom:10px" width="100%">
				<tbody>
				<tr valign="bottom">    
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td valign="top" style="font-family:Calibri,Trebuchet,Arial,sans serif;font-size:15px;line-height:22px;color:#333333">
				<p>Yth. <a href="mailto:'.$email.'" target="_blank">'.$nama.'</a>,
				<br>Anda telah melakukan Aktifasi Akun.</p>
				<p>
				<b>Detail Akun</b><br>
				Nama Lengkap : '.$nama.'<br>
				Username : '.$username.'<br>
				Email : '.$email.'<br>
				No HP : '.$nohp.'<br>
				Jenis Kelamin : '.$jk.'<br>
				Kota/Kab : '.$kota.'<br>
				Provinsi : '.$prov.'<br>
				Saldo Member : '.$balance1.'<br>
				Saldo Reseller : '.$balance2.'<br>
				Status : '.$statusbaru.'<br>
				Waktu Pendaftaran : '.$waktu.'<br>
				<br><br>Salam Hormat,<br>Admin
				</p>
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>
				</tr>
				</tbody>
				</table>
				</td>
				</tr>
				</tbody>
				</table>
				</td>
				</tr>
				</tbody>
				</table>
				<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody>
				<tr>
				<td align="center" width="600" valign="top">
				<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<tbody>
				<tr>
				<td bgcolor="#f2f2f2" style="padding-top:20px"></td>
				</tr>
				<tr>
				<td align="center" valign="top" bgcolor="#f2f2f2">
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody>
				<tr valign="bottom">   
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td>
				<table align="left" border="0" cellpadding="0" cellspacing="0">
				<tbody>
				<tr>
				<td style="font-family:Calibri,Trebuchet,Arial,sans serif;font-size:13px;color:#666;font-weight:bold">
				<span id="m_-6118667421211539915bottomLinks">
				<div style="margin:5px 0;padding:0">
				<span style="display:inline">
				<span>
				<a href="https://www.fornesia.com" style="text-decoration:none" target="_blank">
				Bantuan&nbsp;
				</a>
				</span>
				<span style="color:#ccc"><span> | </span></span>
				<span>
				<a href="https://www.fornesia.com" style="text-decoration:none" target="_blank" >
				Webiste&nbsp;
				</a>
				</span>
				</span>
				</div>
				</span>
				</td>
				</tr>
				</tbody>
				</table>
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>    
				</tr>
				</tbody>
				</table>           
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody>
				<tr valign="bottom">   
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td>
				<p> Jangan balas ke email ini. Untuk menghubungi kami, klik 
				<strong><a href="" style="text-decoration:none" target="_blank" >Bantuan dan Hubungi</a></strong>.
				</p>
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>
				</tr>
				</tbody>
				</table>  
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody>
				<tr valign="bottom">   
				<td width="20" align="center" valign="top">&nbsp;</td>
				<td>
				<span>  
				<table border="0" cellpadding="0" cellspacing="0" id="m_-6118667421211539915emailFooter" style="padding-top:10px;font:12px Arial,Verdana,Helvetica,sans-serif;color:#292929" width="100%">
				<tbody>
				<tr>
				<td>
				<p>Hak Cipta © 2021 fornesia.com.</p>
				</td>
				</tr>
				</tbody>
				</table>
				</span>
				</td>
				<td width="20" align="center" valign="top">&nbsp;</td>    
				</tr>
				</tbody>
				</table>    

				</td>
				</tr>
				</tbody>
				</table>
				</td>

				</tr>
				</tbody>
				</table>
				</td>
				<td bgcolor="#f2f2f2" style="font-size:0px">&nbsp;</td>
				</tr>
				</tbody>
				</table>
	';
	$from_name = 'no reply';
	$from = 'noreply@fornesia.com';
	smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
	
	$successmsg = '
	<div class="alert alert-success" role="alert">
	<center><b>Akun Anda Sudah Aktif, Silahkan Login.</b><br><br>
	<a href="../login.php">
		<button type="button" class="btn btn-success" style="width :100%">
			LOGIN
		</button>
	</a>
	</center>
	</div>';
	}

	}
	else {
		echo "
		<script language = 'javascript'>
		window.location = '../login.php';
		</script>
		";
	}
	
?>
<html lang="en">

<head>
<?php include '../base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />

<title>Aktifasi - Quick SSH</title>

<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>

<body style="background-color:#121215">
	<center>
        <div class="warper container-fluid" style="padding: 0;margin:0;min-height:250px;max-width:600px;">
			<div class="row" style="margin:auto">
            	<div class="col-md-12">
				<div class="page-header" style="margin:25px 0 25px"><h1>Aktifasi</h1></div>
                	<div class="panel panel-default">
                        <div class="panel-body" style="padding:20px 15px 0">
							<span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
							<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                        </div>
                    </div>
                 </div>
			</div>
       </div>
    </center>
	<?php
	$qtsite = "SELECT * FROM site";
	$tsite = $databaseConnection->prepare($qtsite);
	$tsite->execute();
	$site = $tsite->fetchAll();
	foreach ($site as $site) 
	?>
	<p class="text-center">Copyright 2017 <a href="/"><b><?php echo $site['name']; ?></b></a></p>

    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>